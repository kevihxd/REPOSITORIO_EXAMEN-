<div align="center">
<img src="https://dummyimage.com/900x200/1a73e8/ffffff&text=RapidExpress+Management" width="80%" />

<br><br>

# <strong style="font-size:32px;">SISTEMA DE GESTIÓN LOGÍSTICA</strong>
# Plataforma local para administración de envíos, rutas, paquetes y vehículos
</div>
<br>
<div align="center">








</div>
📘 Descripción del Proyecto
<div style="background:#f5f5f5; padding:18px; border-radius:8px; line-height:1.6;">

RapidExpress Management es un sistema desarrollado en Java con base de datos MySQL local, diseñado para gestionar los procesos internos de una empresa de logística.

Cuenta con módulos completos de:

-Gestión de Vehículos  -Gestión de Paquetes  -Gestión de Rutas -Funciones del Operador


La arquitectura del proyecto usa:

| Componente                                 | Descripción                                                                                                          |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------------------- |
| **Programación Orientada a Objetos (POO)** | Modelado de entidades como Vehículo, Paquete, Ruta, etc., con sus atributos y comportamientos.                       |
| **JDBC**                                   | Conexión directa entre Java y la base de datos MySQL local para realizar consultas, inserciones y actualizaciones.   |
| **ArrayList**                              | Estructura de datos utilizada para manejo temporal en memoria durante el flujo de la aplicación.                     |
| **Patrones DAO**                           | Separación clara entre la lógica del negocio y la capa de acceso a datos, facilitando mantenimiento y escalabilidad. |
| **Menús interactivos por consola**         | Interfaz CLI para navegación simple e intuitiva del sistema por parte del operador.                                  |


TECNOLOGIAS USADAS 

| **Tecnología**          | **Uso**            |
| ----------------------- | ------------------ |
| **Java 17+**            | Lógica del sistema |
| **MySQL Local**         | Persistencia       |
| **DBeaver**                | Conexión SQL       |
| **Git / GitHub**        | Versionamiento     |
| **NetBeans / IntelliJ** | IDE recomendados   |


Estructura de la Base de Datos

  
| **Elemento**         | **Descripción / Función**                               |
| -------------------- | ------------------------------------------------------- |
| **Vehículos**        | Unidades de transporte utilizadas para las rutas.       |
| **Conductores**      | Personal asignado a los vehículos durante las rutas.    |
| **Paquetes**         | Envíos registrados en el sistema.                       |
| **Rutas**            | Recorridos asignados a un conductor y un vehículo.      |
| **Detalle de Rutas** | Relación entre cada ruta y los paquetes que transporta. |

RELACIONES CLAVE: 
| **Relación**         | **Descripción**                                    |
| -------------------- | -------------------------------------------------- |
| **Vehículo → Rutas** | Un vehículo puede participar en *múltiples* rutas. |
| **Ruta → Paquetes**  | Una ruta puede contener *muchos* paquetes.         |
| **Paquete → Ruta**   | Cada paquete pertenece a *una única* ruta.         |

![Imagen de WhatsApp 2025-12-03 a las 20 27 20_bd7949f7](https://github.com/user-attachments/assets/d3b9816b-d721-4697-a3c2-52d031724ccd)


📁 Instalación y Ejecución
# 1. Clonar el repositorio
git clone https://github.com/usuario/rapidexpress-management.git
cd rapidexpress-management

# 2. Crear Base de Datos Local

Ejecutar el archivo: Database.sql

Esto creará todas las tablas necesarias. 

# 3. Configurar JDBC

Editar: src/util/ConexionBD.java
private final String URL = "jdbc:mysql://localhost:3306/rapidexpress";
private final String USER = "root";
private final String PASSWORD = "";

Si usas otro puerto: jdbc:mysql://localhost:3307/rapidexpress

# 4. Ejecutar el proyecto
## Desde IDE
Ejecutar la clase: Main.java

## Desde consola
javac Main.java
java Main
</div> </div>

# USOS DE MODULOS DEL SISTEMA: 

| **Módulo**       | **Funciones Disponibles**                                                            |
| ---------------- | ------------------------------------------------------------------------------------ |
| 🚚 **Vehículos** | • Registrar vehículos<br>• Listar vehículos<br>• Cambiar estado<br>• Asignar a rutas |
| 📦 **Paquetes**  | • Registrar paquetes<br>• Listar paquetes<br>• Cambiar estado<br>• Asignar a ruta    |
| 🛣 **Rutas**     | • Crear rutas<br>• Agregar paquetes<br>• Cambiar estado<br>• Finalizar ruta          |


# EQUIPO DE DESARROLLO (JAVA - SURA) 
<img width="200" height="200" alt="image" src="https://github.com/user-attachments/assets/dc7b9e7d-a548-4de9-948c-91225a318d37" />
<img width="200" height="200" alt="image" src="https://github.com/user-attachments/assets/1af6ccaf-f26a-4129-b69d-1f0628135f3f" />
<img width="200" height="200" alt="image" src="https://github.com/user-attachments/assets/0bce3a13-03a8-4c87-b777-1da5ab4043ba" />
<img width="200" height="200" alt="image" src="https://github.com/user-attachments/assets/23f59e75-766c-4ad2-b739-4397ab2f1d4d" />


