USE rapidexpress;

-- fn_capacidad_restante_ruta
DROP FUNCTION IF EXISTS fn_capacidad_restante_ruta 

CREATE FUNCTION fn_capacidad_restante_ruta(p_id_ruta INT)
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE v_capacidad INT;
    DECLARE v_peso_actual INT;

    SELECT v.capacidad_kg INTO v_capacidad
    FROM rutas r
    JOIN vehiculos v ON r.id_vehiculo = v.id_vehiculo
    WHERE r.id_ruta = p_id_ruta
    LIMIT 1;

    IF v_capacidad IS NULL THEN
        RETURN NULL;
    END IF;

    SET v_peso_actual = fn_calcular_peso_ruta(p_id_ruta);

    RETURN (v_capacidad - v_peso_actual);
END;


-- fn_contar_paquetes_por_estado
DROP FUNCTION IF EXISTS fn_contar_paquetes_por_estado 

CREATE FUNCTION fn_contar_paquetes_por_estado(p_estado VARCHAR(50))
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE v_count INT DEFAULT 0;

    SELECT COUNT(*) INTO v_count
    FROM paquetes
    WHERE estado_paquete = p_estado;

    RETURN v_count;
END;

-- Obtener número de paquetes entregados por un conductor
DROP FUNCTION IF EXISTS paquetes_entregados_conductor

CREATE FUNCTION paquetes_entregados_conductor(p_id_conductor INT)
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE total INT;

    SELECT COUNT(*) INTO total
    FROM paquetes p
    JOIN detalle_ruta dr ON dr.id_paquete = p.id_paquete
    JOIN rutas r ON r.id_ruta = dr.id_ruta
    WHERE r.id_conductor = p_id_conductor
      AND p.estado_paquete = 'Entregado';

    RETURN total;
END ;