CREATE DATABASE IF NOT EXISTS rapidexpress;
USE rapidexpress;

-- ========================
--  VEHÍCULOS
-- ========================
CREATE TABLE vehiculos (
    id_vehiculo INT AUTO_INCREMENT PRIMARY KEY,
    placa VARCHAR(20) NOT NULL UNIQUE,
    marca VARCHAR(100),
    modelo VARCHAR(100),
    anio_fabricacion YEAR,
    capacidad_kg INT NOT NULL DEFAULT 0,
    estado_vehiculo ENUM('Disponible','Asignado','En Ruta','En Mantenimiento') NOT NULL DEFAULT 'Disponible',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ========================
--  CONDUCTORES
-- ========================
CREATE TABLE conductores (
    id_conductor INT AUTO_INCREMENT PRIMARY KEY,
    identificacion VARCHAR(50) NOT NULL UNIQUE,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    tipo_licencia VARCHAR(50),
    telefono VARCHAR(50),
    estado_conductor ENUM('Activo','Vacaciones','Inactivo') NOT NULL DEFAULT 'Activo',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ========================
--  CONDUCTOR-VEHÍCULO
-- ========================
CREATE TABLE conductor_vehiculo (
    id_asignacion INT AUTO_INCREMENT PRIMARY KEY,
    id_conductor INT NOT NULL,
    id_vehiculo INT NOT NULL,
    fecha_asignacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_fin_asignacion DATETIME NULL,
    FOREIGN KEY (id_conductor) REFERENCES conductores(id_conductor) ON DELETE CASCADE,
    FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id_vehiculo) ON DELETE CASCADE
);

-- ========================
--  PERSONAS 
-- ========================
CREATE TABLE personas (
    id_persona INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    telefono VARCHAR(50),
    email VARCHAR(150),
    direccion VARCHAR(250)
);

-- ========================
--  PAQUETES
-- ========================
CREATE TABLE paquetes (
    id_paquete INT AUTO_INCREMENT PRIMARY KEY,
    Numero_Guia VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT,
    peso INT NOT NULL DEFAULT 0, 
    dimensiones VARCHAR(50),
    remitente_id INT NULL,
    destinatario_id INT NULL,
    direccion_origen TEXT,
    direccion_destino TEXT,
    estado_paquete ENUM('En Bodega','Asignado a Ruta','En Transito','Entregado','Devuelto') NOT NULL DEFAULT 'En Bodega',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (remitente_id) REFERENCES personas(id_persona) ON DELETE SET NULL,
    FOREIGN KEY (destinatario_id) REFERENCES personas(id_persona) ON DELETE SET NULL
);

    

-- ========================
--  RUTAS
-- ========================
CREATE TABLE rutas (
    id_ruta INT AUTO_INCREMENT PRIMARY KEY,
    id_vehiculo INT NOT NULL,
    id_conductor INT NOT NULL,
    estado_ruta ENUM('Planificada','En Curso','Finalizada','Cancelada') NOT NULL DEFAULT 'Planificada',
    fecha_inicio DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_fin DATETIME NULL,
    FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id_vehiculo) ON DELETE RESTRICT,
    FOREIGN KEY (id_conductor) REFERENCES conductores(id_conductor) ON DELETE RESTRICT
);

-- ========================
--  DETALLE RUTA (paquetes asignados)
-- ========================
CREATE TABLE detalle_ruta (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_ruta INT NOT NULL,
    id_paquete INT NOT NULL,
    fecha_asignacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_entrega DATETIME NULL,
    estado_detalle ENUM('PENDIENTE','EN_TRANSITO','ENTREGADO','DEVUELTO') NOT NULL DEFAULT 'PENDIENTE',
    FOREIGN KEY (id_ruta) REFERENCES rutas(id_ruta) ON DELETE CASCADE,
    FOREIGN KEY (id_paquete) REFERENCES paquetes(id_paquete) ON DELETE CASCADE
);

-- ===========================
--  HISTORIAL MANTENIMIENTOS
-- ===========================
CREATE TABLE historial_mantenimiento (
    id_mantenimiento INT AUTO_INCREMENT PRIMARY KEY,
    id_vehiculo INT NOT NULL,
    fecha_mantenimiento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    descripcion TEXT,
    tipo VARCHAR(100),
    costo DECIMAL(10,2) DEFAULT 0.00,
    realizado_por VARCHAR(150) NULL,
    FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id_vehiculo) ON DELETE CASCADE
);

-- ========================
--  AUDITORÍA
-- ========================
CREATE TABLE auditoria (
    id_auditoria INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(150) NULL,
    operacion VARCHAR(100) NOT NULL,
    descripcion TEXT,
    tabla_afectada VARCHAR(100) NULL,
    id_registro INT NULL,
    fecha_hora DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ========================
-- ÍNDICES
-- ========================
CREATE INDEX idx_paquete_estado ON paquetes (estado_paquete);
CREATE INDEX idx_ruta_estado ON rutas (estado_ruta);
CREATE INDEX idx_conductor_estado ON conductores (estado_conductor);
CREATE INDEX idx_vehiculo_estado ON vehiculos (estado_vehiculo);
CREATE INDEX idx_detalle_ruta_ruta ON detalle_ruta (id_ruta);
CREATE INDEX idx_detalle_ruta_paquete ON detalle_ruta (id_paquete);
