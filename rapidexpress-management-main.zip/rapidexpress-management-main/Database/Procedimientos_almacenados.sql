USE rapidexpress;
-- ============================================
-- 1. Registrar un vehículo
-- ============================================
CREATE PROCEDURE registrar_vehiculo(
    IN p_placa VARCHAR(10),
    IN p_marca VARCHAR(50),
    IN p_modelo VARCHAR(50),
    IN p_anio YEAR,
    IN p_capacidad INT
)
BEGIN
    INSERT INTO vehiculos (placa, marca, modelo, anio_fabricacion, capacidad_kg, estado_vehiculo)
    VALUES (p_placa, p_marca, p_modelo, p_anio, p_capacidad, 'Disponible');

    SELECT 'Vehículo registrado correctamente' AS mensaje;
END;


-- ============================================
-- 2. Asignar un conductor a un vehículo
-- ============================================
CREATE PROCEDURE asignar_conductor(
    IN p_id_conductor INT,
    IN p_id_vehiculo INT
)
BEGIN
    -- Registrar asignación
    INSERT INTO conductor_vehiculo (id_conductor, id_vehiculo, fecha_asignacion)
    VALUES (p_id_conductor, p_id_vehiculo, NOW());

    -- Marcar conductor activo
    UPDATE conductores
    SET estado_conductor = 'Activo'
    WHERE id_conductor = p_id_conductor;

    -- El vehículo queda disponible hasta que inicie ruta
    UPDATE vehiculos
    SET estado_vehiculo = 'Disponible'
    WHERE id_vehiculo = p_id_vehiculo;

    SELECT 'Conductor asignado correctamente' AS mensaje;
END;


-- ============================================
-- 3. Crear una ruta
-- ============================================
CREATE PROCEDURE crear_ruta(
    IN p_id_vehiculo INT,
    IN p_id_conductor INT
)
BEGIN
    INSERT INTO rutas (id_vehiculo, id_conductor, estado_ruta, fecha_inicio)
    VALUES (p_id_vehiculo, p_id_conductor, 'En Curso', NOW());

    UPDATE vehiculos
    SET estado_vehiculo = 'En Ruta'
    WHERE id_vehiculo = p_id_vehiculo;

    UPDATE conductores
    SET estado_conductor = 'Activo'
    WHERE id_conductor = p_id_conductor;

    SELECT 'Ruta creada e iniciada correctamente' AS mensaje;
END;