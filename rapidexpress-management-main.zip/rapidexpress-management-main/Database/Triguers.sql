USE rapidexpress;

-- =====================================================
--      Auditoría al insertar un paquete
-- =====================================================

DROP TRIGGER IF EXISTS trg_audit_paquete_after_insert;

CREATE TRIGGER trg_audit_paquete_after_insert
AFTER INSERT ON paquetes
FOR EACH ROW
BEGIN
    INSERT INTO auditoria (usuario, operacion, descripcion, tabla_afectada, id_registro)
    VALUES (
        CURRENT_USER(),
        'INSERT',
        CONCAT('Se registró el paquete ', NEW.id_paquete),
        'paquetes',
        NEW.id_paquete
    );
END;


-- =====================================================
--       Finalizar ruta  (PAQUETES ENTREGADOS)
-- =====================================================

DROP TRIGGER IF EXISTS trg_update_paquetes_after_ruta_finalizada;

CREATE TRIGGER trg_update_paquetes_after_ruta_finalizada
AFTER UPDATE ON rutas
FOR EACH ROW
BEGIN
    IF OLD.estado_ruta = 'En Curso' AND NEW.estado_ruta = 'Finalizada' THEN

        UPDATE detalle_ruta
        SET estado_detalle = 'ENTREGADO',
            fecha_entrega = NOW()
        WHERE id_ruta = NEW.id_ruta;

        UPDATE paquetes
        SET estado_paquete = 'Entregado'
        WHERE id_paquete IN (
            SELECT id_paquete
            FROM detalle_ruta
            WHERE id_ruta = NEW.id_ruta
        );

        INSERT INTO auditoria (usuario, operacion, descripcion, tabla_afectada, id_registro)
        VALUES (
            CURRENT_USER(),
            'UPDATE',
            CONCAT('Ruta ', NEW.id_ruta, ' finalizada. Paquetes marcados como entregados.'),
            'rutas',
            NEW.id_ruta
        );

    END IF;
END;

-- =====================================================
--     Validar capacidad del vehículo
-- =====================================================

DROP TRIGGER IF EXISTS trg_validar_capacidad_before_insert_detalle;

CREATE TRIGGER trg_validar_capacidad_before_insert_detalle
BEFORE INSERT ON detalle_ruta
FOR EACH ROW
BEGIN
    DECLARE capacidad INT;
    DECLARE peso_actual INT;
    DECLARE peso_nuevo INT;

    SELECT v.capacidad_kg INTO capacidad
    FROM rutas r
    JOIN vehiculos v ON r.id_vehiculo = v.id_vehiculo
    WHERE r.id_ruta = NEW.id_ruta;

    SELECT IFNULL(SUM(p.peso),0) INTO peso_actual
    FROM detalle_ruta dr
    JOIN paquetes p ON dr.id_paquete = p.id_paquete
    WHERE dr.id_ruta = NEW.id_ruta;

    SELECT peso INTO peso_nuevo
    FROM paquetes
    WHERE id_paquete = NEW.id_paquete;

    IF (peso_actual + peso_nuevo) > capacidad THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Capacidad del vehículo excedida para esta ruta.';
    END IF;
END;

-- =====================================================
--  b registrar un mantenimiento
-- =====================================================

DROP TRIGGER IF EXISTS trg_audit_mantenimiento_after_insert;

CREATE TRIGGER trg_audit_mantenimiento_after_insert
AFTER INSERT ON historial_mantenimiento
FOR EACH ROW
BEGIN
    INSERT INTO auditoria (usuario, operacion, descripcion, tabla_afectada, id_registro)
    VALUES (
        CURRENT_USER(),
        'INSERT',
        CONCAT('Se registró mantenimiento al vehículo ', NEW.id_vehiculo),
        'historial_mantenimiento',
        NEW.id_mantenimiento
    );
END;

-- =====================================================
-- 05  Registrar auditoría de conductor asignado
-- =====================================================

DROP TRIGGER IF EXISTS trg_audit_asignacion_conductor_after_insert;

CREATE TRIGGER trg_audit_asignacion_conductor_after_insert
AFTER INSERT ON conductor_vehiculo
FOR EACH ROW
BEGIN
    INSERT INTO auditoria (usuario, operacion, descripcion, tabla_afectada, id_registro)
    VALUES (
        CURRENT_USER(),
        'INSERT',
        CONCAT('Conductor ', NEW.id_conductor, ' asignado al vehículo ', NEW.id_vehiculo),
        'conductor_vehiculo',
        NEW.id_asignacion
    );
END;