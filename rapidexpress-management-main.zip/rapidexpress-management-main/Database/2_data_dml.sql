USE rapidexpress;

-- =======================================================
-- =============== 1. VEHICULOS =====================
-- =======================================================
INSERT INTO vehiculos (placa, marca, modelo, anio_fabricacion, capacidad_kg, estado_vehiculo) VALUES
('ABC123', 'Chevrolet', 'N300', 2019, 800, 'Disponible'),
('XYZ987', 'Renault', 'Kangoo', 2020, 750, 'Disponible'),
('JKL456', 'Nissan', 'Frontier', 2018, 1200, 'En Mantenimiento'),
('MNO321', 'Toyota', 'Hiace', 2021, 1000, 'Disponible'),
('PRS741', 'Hyundai', 'H100', 2017, 900, 'Disponible'),
('TRZ852', 'Chevrolet', 'D-Max', 2022, 1300, 'Disponible'),
('QWE369', 'Ford', 'Transit', 2020, 1400, 'Disponible'),
('RTY159', 'Mercedes', 'Sprinter', 2019, 1600, 'Disponible'),
('UIO753', 'Kia', 'Bongo', 2016, 850, 'En Mantenimiento'),
('AAA111', 'JAC', 'Urban', 2021, 950, 'Disponible'),
('BBB222', 'Foton', 'Van', 2018, 1100, 'Disponible'),
('CCC333', 'Volkswagen', 'Crafter', 2022, 1700, 'Disponible'),
('DDD444', 'Chevrolet', 'NHR', 2019, 2000, 'En Ruta'),
('EEE555', 'Chevrolet', 'NKR', 2020, 2500, 'Disponible'),
('FFF666', 'Dodge', 'RAM', 2017, 1200, 'Disponible'),
('GGG777', 'Ford', 'Ranger', 2023, 1300, 'Disponible'),
('HHH888', 'Toyota', 'Hilux', 2018, 1000, 'Disponible'),
('III999', 'Isuzu', 'NPR', 2019, 2800, 'Disponible'),
('JJJ000', 'Hino', 'Dutro', 2020, 3500, 'Disponible'),
('KLM123', 'Chevrolet', 'LUV', 2016, 700, 'Disponible');

-- =======================================================
-- =============== 2. CONDUCTORES ===================
-- =======================================================
INSERT INTO conductores (identificacion, nombre, apellido, tipo_licencia, telefono, estado_conductor) VALUES
('1001', 'Carlos', 'Perez', 'C1', '3001110001', 'Activo'),
('1002', 'Ana', 'Gomez', 'C1', '3001110002', 'Activo'),
('1003', 'Luis', 'Martinez', 'C1', '3001110003', 'Vacaciones'),
('1004', 'Maria', 'Rodriguez', 'C2', '3001110004', 'Activo'),
('1005', 'Jorge', 'Alvarez', 'C1', '3001110005', 'Activo'),
('1006', 'Sofia', 'Torres', 'C1', '3001110006', 'Activo'),
('1007', 'Diego', 'Suarez', 'C1', '3001110007', 'Activo'),
('1008', 'Laura', 'Ruiz', 'C1', '3001110008', 'Activo'),
('1010', 'Pedro', 'Díaz', 'B1', '3010000000', 'Activo'),
('1011', 'Sergio', 'Herrera', 'C1', '3021111111', 'Activo'),
('1012', 'Héctor', 'Medina', 'C1', '3022222222', 'Activo'),
('1013', 'Adrián', 'Rodríguez', 'C2', '3023333333', 'Activo'),
('1014', 'Kevin', 'Moreno', 'B2', '3024444444', 'Activo'),
('1015', 'Sebastián', 'León', 'C1', '3025555555', 'Activo'),
('1016', 'Daniel', 'Mena', 'C1', '3026666666', 'Inactivo'),
('1017', 'Alan', 'Paez', 'C2', '3027777777', 'Activo'),
('1018', 'Martín', 'Duarte', 'C1', '3028888888', 'Activo'),
('1019', 'Ricardo', 'Santamaría', 'C2', '3029999999', 'Vacaciones'),
('1020', 'Samuel', 'Cárdenas', 'B1', '3031010101', 'Activo');

-- =======================================================
-- =============== 3. CONDUCTOR-VEHICULO ==================
-- =======================================================
INSERT INTO conductor_vehiculo (id_conductor, id_vehiculo, fecha_asignacion, fecha_fin_asignacion) VALUES
(1, 1, '2025-02-01 07:30:00', NULL),
(2, 3, '2025-02-01 08:10:00', NULL),
(3, 4, '2025-01-20 09:00:00', '2025-01-20 16:00:00'),
(4, 2, '2025-01-22 07:45:00', '2025-01-22 14:30:00'),
(5, 5, '2025-02-03 06:50:00', NULL),
(6, 6, '2025-01-25 08:20:00', '2025-01-25 15:00:00'),
(7, 7, '2025-01-10 08:00:00', '2025-01-20 12:00:00'),
(8, 8, '2025-01-21 08:30:00', NULL),
(9, 9, '2024-12-15 07:00:00', '2025-01-05 17:30:00'),
(10, 10, '2025-02-05 09:00:00', NULL);

-- =======================================================
-- =============== 4. PERSONAS ======================
-- =======================================================
INSERT INTO personas (nombre, apellido, telefono, email, direccion) VALUES
('Ana Sofía', 'Ramírez Torres', '3004125896', 'ana.ramirez@example.com', 'Cra 45 #12-67, Bogotá'),
('Juan Esteban', 'Bello Rojas', '3019874521', 'juan.bello@example.com', 'Cll 98 #20-45, Medellín'),
('María Fernanda', 'Quintero', '3156748230', 'maria.quintero@example.com', 'Av. Caracas #34-80, Bogotá'),
('Carlos Andrés', 'Prieto', '3105948372', 'carlos.prieto@example.com', 'Cll 56 #8-12, Cali'),
('Laura Valentina', 'Pardo', '3124589673', 'laura.pardo@example.com', 'Cra 22 #15-23, Bucaramanga'),
('Julián Felipe', 'Osorio', '3008764532', 'julian.osorio@example.com', 'Cll 44 #19-60, Pereira'),
('Diana Marcela', 'López', '3013459872', 'diana.lopez@example.com', 'Cra 10 #25-82, Bogotá'),
('Sebastián Morales', 'Vargas', '3226789012', 'sebastian.morales@example.com', 'Cll 120 #45-77, Medellín'),
('Paola Andrea', 'Gutiérrez', '3146759082', 'paola.gutierrez@example.com', 'Cra 80 #33-54, Cali'),
('Luis Alberto', 'Hernández', '3118907654', 'luis.hernandez@example.com', 'Cll 72 #10-20, Barranquilla'),
('Camila Alejandra', 'Soriano', '3015789423', 'camila.soriano@example.com', 'Cra 50 #21-19, Cartagena'),
('Nicolás Santiago', 'Mejía', '3154809732', 'nicolas.mejia@example.com', 'Cll 32 #7-77, Bogotá'),
('Tatiana Robles', 'Martínez', '3206785432', 'tatiana.robles@example.com', 'Cll 23 #14-61, Manizales'),
('Andrés Felipe', 'Torres', '3179054621', 'andres.torres@example.com', 'Cra 90 #12-40, Cali'),
('Vanessa Contreras', 'Silva', '3164125783', 'vanessa.contreras@example.com', 'Cll 50 #18-52, Bogotá'),
('Miguel Ángel', 'Suárez', '3127895421', 'miguel.suarez@example.com', 'Cra 23 #6-99, Medellín'),
('Luisa Fernanda', 'Castaño', '3056891274', 'luisa.castano@example.com', 'Cll 80 #40-33, Cali'),
('Jorge Eliecer', 'Páez', '3185740923', 'jorge.paez@example.com', 'Cra 15 #30-61, Bogotá'),
('Stephanie Andrea', 'Roldán', '3104567290', 'stephanie.roldan@example.com', 'Cll 67 #22-10, Medellín'),
('David Mauricio', 'Correa', '3002459786', 'david.correa@example.com', 'Cra 60 #17-45, Cali');

-- =======================================================
-- =============== 5. PAQUETES ======================
-- =======================================================

INSERT INTO paquetes 
(Numero_Guia, descripcion, peso, dimensiones, remitente_id, destinatario_id, direccion_origen, direccion_destino, estado_paquete)
VALUES
('TRK0001', 'Documentos importantes', 2, '10cmx30cm', 1, 2, 'Bodega Central Bogotá', 'Calle 45 #12-67 Bogotá', 'En Bodega'),
('TRK0002', 'Caja con electrónicos', 8, '40cmx30cm', 3, 4, 'Bodega Norte Medellín', 'Cra 90 #12-40 Cali', 'En Bodega'),
('TRK0003', 'Ropa varia', 5, '50cmx30cm', 5, 6, 'Bodega Cali Oeste', 'Calle 98 #20-45 Medellín', 'En Bodega'),
('TRK0004', 'Repuestos mecánicos', 14, '70cmx40cm', 7, 8, 'Bodega Industrial Bogotá', 'Cra 22 #15-23 Bucaramanga', 'En Bodega'),
('TRK0005', 'Medicamentos fríos', 3, '20cmx20cm', 9, 10, 'Laboratorio FarmaBogotá', 'Calle 72 #10-20 Barranquilla', 'En Bodega'),
('TRK0006', 'Artículos frágiles', 7, '40cmx40cm', 11, 12, 'Bodega de Cristalería', 'Calle 23 #14-61 Manizales', 'En Bodega'),
('TRK0007', 'Calzado premium', 4, '20cmx30cm', 13, 14, 'Bodega Outlet Cali', 'Cra 50 #21-19 Cartagena', 'En Bodega'),
('TRK0008', 'Electrodoméstico pequeño', 11, '60cmx40cm', 15, 16, 'Depósito Medellín', 'Calle 80 #40-33 Cali', 'En Bodega'),
('TRK0009', 'Herramientas metálicas', 12, '70cmx50cm', 17, 18, 'Zona Industrial Cali', 'Cra 10 #25-82 Bogotá', 'En Bodega'),
('TRK0010', 'Partes electrónicas', 2, '15cmx10cm', 19, 20, 'Bodega Tecnológica Medellín', 'Cra 23 #6-99 Medellín', 'En Bodega'),
('TRK0011', 'Juguetes varios', 5, '50cmx40cm', 2, 5, 'Bodega Bogotá Norte', 'Cra 15 #30-61 Bogotá', 'En Bodega'),
('TRK0012', 'Pequeño electrodoméstico', 9, '60cmx30cm', 6, 1, 'Calle 120 #45-77 Medellín', 'Cra 45 #12-67 Bogotá', 'En Bodega'),
('TRK0013', 'Libros y material escolar', 6, '40cmx25cm', 8, 3, 'Bodega Educativa Bogotá', 'Av Caracas #34-80 Bogotá', 'En Bodega'),
('TRK0014', 'Equipo electrónico frágil', 4, '30cmx30cm', 10, 7, 'Bodega Electrónica', 'Cra 80 #33-54 Cali', 'En Bodega'),
('TRK0015', 'Componentes mecánicos', 18, '80cmx60cm', 12, 9, 'Bodega Maquinaria', 'Calle 56 #8-12 Cali', 'En Bodega'),
('TRK0016', 'Productos de aseo', 5, '40cmx20cm', 14, 11, 'Calle 67 #22-10 Medellín', 'Cra 22 #15-23 Bucaramanga', 'En Bodega'),
('TRK0017', 'Insumos médicos', 7, '60cmx20cm', 16, 13, 'Hospital Central Medellín', 'Calle 44 #19-60 Pereira', 'En Bodega'),
('TRK0018', 'Bebidas embotelladas', 9, '60cmx50cm', 18, 15, 'Bodega Cali Sur', 'Calle 50 #18-52 Bogotá', 'En Bodega'),
('TRK0019', 'Perfumería', 3, '30cmx20cm', 20, 17, 'Centro Distribución Bogotá', 'Cra 90 #12-40 Cali', 'En Bodega'),
('TRK0020', 'Accesorios deportivos', 6, '50cmx35cm', 4, 19, 'Bodega Deportiva Medellín', 'Cra 32 #7-77 Bogotá', 'En Bodega');

-- =======================================================
-- =============== 6. RUTAS  ==========================
-- =======================================================

INSERT INTO rutas (id_vehiculo, id_conductor, estado_ruta, fecha_inicio, fecha_fin) VALUES
(1, 1, 'Planificada', '2025-02-01 08:00:00', NULL),
(2, 2, 'Planificada', '2025-02-01 09:00:00', NULL),
(3, 3, 'Planificada', '2025-02-02 07:30:00', NULL),
(4, 4, 'Planificada', '2025-02-02 08:15:00', NULL),
(5, 5, 'Planificada', '2025-02-02 09:45:00', NULL),
(6, 6, 'En Curso', '2025-02-03 07:00:00', NULL),
(7, 7, 'En Curso', '2025-02-03 08:10:00', NULL),
(8, 8, 'En Curso', '2025-02-03 09:30:00', NULL),
(9, 9, 'Finalizada', '2025-01-30 08:00:00', '2025-01-30 15:30:00'),
(10, 10, 'Finalizada', '2025-01-31 09:00:00', '2025-01-31 14:20:00');

-- =======================================================
-- =============== 7. DETALLE RUTA ========================
-- =======================================================
INSERT INTO detalle_ruta (id_ruta, id_paquete, fecha_asignacion, fecha_entrega, estado_detalle) VALUES
(1, 1, NOW(), NULL, 'PENDIENTE'),
(1, 2, NOW(), NULL, 'PENDIENTE'),
(2, 3, NOW(), NULL, 'PENDIENTE'),
(2, 4, NOW(), NULL, 'PENDIENTE'),
(3, 5, NOW(), NULL, 'PENDIENTE'),
(3, 6, NOW(), NULL, 'PENDIENTE'),
(6, 7, '2025-02-03 07:10:00', NULL, 'EN_TRANSITO'),
(6, 8, '2025-02-03 07:10:00', NULL, 'EN_TRANSITO'),
(7, 9, '2025-02-03 08:20:00', NULL, 'EN_TRANSITO'),
(7, 10, '2025-02-03 08:20:00', NULL, 'EN_TRANSITO'),
(8, 11, '2025-02-03 09:40:00', NULL, 'EN_TRANSITO'),
(8, 12, '2025-02-03 09:40:00', NULL, 'EN_TRANSITO'),
(9, 13, '2025-01-30 08:10:00', '2025-01-30 11:00:00', 'ENTREGADO'),
(9, 14, '2025-01-30 08:10:00', '2025-01-30 13:15:00', 'ENTREGADO'),
(10, 15, '2025-01-31 09:10:00', '2025-01-31 12:00:00', 'ENTREGADO'),
(10, 16, '2025-01-31 09:10:00', '2025-01-31 12:45:00', 'ENTREGADO');

-- =======================================================
-- =============== 8. HISTORIAL DE MANTENIMIENTO ==========
-- =======================================================
INSERT INTO historial_mantenimiento 
(id_vehiculo, fecha_mantenimiento, descripcion, tipo, costo, realizado_por)
VALUES
(1, '2025-01-15 10:00:00', 'Cambio de aceite y filtros', 'Preventivo', 250000, 'Taller Central'),
(2, '2025-01-20 14:00:00', 'Revisión de frenos', 'Correctivo', 320000, 'Taller Norte'),
(3, '2025-01-25 09:30:00', 'Alineación y balanceo', 'Preventivo', 180000, 'Taller Cali'),
(4, '2025-01-28 11:15:00', 'Cambio de batería', 'Correctivo', 450000, 'Taller Central'),
(5, '2025-02-01 16:00:00', 'Revisión general', 'Preventivo', 200000, 'Taller Express'),
(6, '2025-02-03 07:30:00', 'Cambio de llantas', 'Correctivo', 800000, 'Taller Medellín'),
(7, '2025-02-03 15:00:00', 'Cambio de pastillas de freno', 'Correctivo', 350000, 'Taller Bucaramanga'),
(8, '2025-02-04 09:45:00', 'Lubricación completa', 'Preventivo', 150000, 'Taller Central'),
(9, '2025-02-05 10:10:00', 'Cambio de correa', 'Correctivo', 500000, 'Taller Cali'),
(10, '2025-02-06 13:20:00', 'Mantenimiento eléctrico', 'Correctivo', 380000, 'Técnico Independiente'),
(11, '2025-02-07 08:55:00', 'Revisión sistema de carga', 'Preventivo', 210000, 'Taller Norte'),
(12, '2025-02-08 15:10:00', 'Cambio de amortiguadores', 'Correctivo', 600000, 'Taller Medellín');

-- =======================================================
-- =============== 9. AUDITORÍA  =================
-- =======================================================
INSERT INTO auditoria (usuario, operacion, descripcion, tabla_afectada, id_registro) VALUES
('admin', 'INSERT', 'Creación de 20 paquetes iniciales', 'paquetes', NULL),
('operador1', 'INSERT', 'Ruta 1 planificada', 'rutas', 1),
('operador1', 'INSERT', 'Ruta 2 planificada', 'rutas', 2),
('operador2', 'UPDATE', 'Ruta 9 finalizada correctamente', 'rutas', 9),
('operador2', 'UPDATE', 'Ruta 10 finalizada correctamente', 'rutas', 10),
('sistema', 'UPDATE', 'Paquetes 13 y 14 marcados como entregados al finalizar ruta 9', 'detalle_ruta', 13),
('sistema', 'UPDATE', 'Paquetes 15 y 16 marcados como entregados al finalizar ruta 10', 'detalle_ruta', 15),
('admin', 'INSERT', 'Registro de mantenimiento del vehículo 1', 'historial_mantenimiento', 1),
('admin', 'INSERT', 'Registro de mantenimiento del vehículo 2', 'historial_mantenimiento', 2);

