USE rapidexpress;

-- ==========================================
-- 1. CREACIÓN DE ROLES
-- ==========================================
CREATE ROLE IF NOT EXISTS Admin;
CREATE ROLE IF NOT EXISTS Operador;
CREATE ROLE IF NOT EXISTS Auditor;
CREATE ROLE IF NOT EXISTS Cliente;

-- ==========================================
-- 2. PRIVILEGIOS PARA CADA ROL
-- ==========================================

-- ADMIN: acceso total
GRANT ALL PRIVILEGES ON rapidexpress.* TO Admin WITH GRANT OPTION;

-- OPERADOR: manejo operativo
GRANT SELECT, INSERT, UPDATE ON rapidexpress.paquetes TO Operador;
GRANT SELECT, INSERT, UPDATE ON rapidexpress.rutas TO Operador;
GRANT SELECT, INSERT, UPDATE ON rapidexpress.detalle_ruta TO Operador;
GRANT SELECT ON rapidexpress.vehiculos TO Operador;
GRANT SELECT ON rapidexpress.conductores TO Operador;
GRANT SELECT, INSERT ON rapidexpress.conductor_vehiculo TO Operador;
GRANT SELECT ON rapidexpress.personas TO Operador;

-- AUDITOR: solo lectura
GRANT SELECT ON rapidexpress.* TO Auditor;

-- CLIENTE: solo su información
CREATE OR REPLACE VIEW vista_paquetes_cliente AS
SELECT 
    id_paquete,
    Numero_Guia,
    descripcion,
    estado_paquete,
    remitente_id,
    destinatario_id,
    created_at
FROM paquetes;

GRANT SELECT ON rapidexpress.vista_paquetes_cliente TO Cliente;
GRANT SELECT ON rapidexpress.personas TO Cliente;

-- ==========================================
-- 3. CREACIÓN DE USUARIOS
-- ==========================================

CREATE USER IF NOT EXISTS 'admin_user'@'localhost' IDENTIFIED BY 'Admin#2025';
CREATE USER IF NOT EXISTS 'operador_user'@'localhost' IDENTIFIED BY 'Operador#2025';
CREATE USER IF NOT EXISTS 'auditor_user'@'localhost' IDENTIFIED BY 'Auditor#2025';
CREATE USER IF NOT EXISTS 'cliente_user'@'localhost' IDENTIFIED BY 'Cliente#2025';

-- ==========================================
-- 4. ASIGNACIÓN DE ROLES A USUARIOS
-- ==========================================

GRANT Admin    TO 'admin_user'@'localhost';
GRANT Operador TO 'operador_user'@'localhost';
GRANT Auditor  TO 'auditor_user'@'localhost';
GRANT Cliente  TO 'cliente_user'@'localhost';

SET DEFAULT ROLE Admin    FOR 'admin_user'@'localhost';
SET DEFAULT ROLE Operador FOR 'operador_user'@'localhost';
SET DEFAULT ROLE Auditor  FOR 'auditor_user'@'localhost';
SET DEFAULT ROLE Cliente  FOR 'cliente_user'@'localhost';


-- ==========================================
-- 5. SEGURIDAD ADICIONAL
-- ==========================================

ALTER USER 'cliente_user'@'localhost' WITH MAX_QUERIES_PER_HOUR 200;
ALTER USER 'auditor_user'@'localhost' WITH MAX_QUERIES_PER_HOUR 500;

FLUSH PRIVILEGES;

-- ==========================================
-- 6. VISTAS ADICIONALES
-- ==========================================

CREATE OR REPLACE VIEW vista_vehiculos_disponibles AS
SELECT *
FROM vehiculos
WHERE estado_vehiculo = 'Disponible';

CREATE OR REPLACE VIEW vista_paquetes_transito AS
SELECT *
FROM paquetes
WHERE estado_paquete = 'En Transito';

CREATE OR REPLACE VIEW vista_historial_rutas AS
SELECT 
    r.id_ruta,
    v.placa,
    r.fecha_inicio,
    r.fecha_fin,
    r.estado_ruta
FROM rutas r
JOIN vehiculos v ON r.id_vehiculo = v.id_vehiculo;

CREATE OR REPLACE VIEW vista_conductores_activos AS
SELECT *
FROM conductores
WHERE estado_conductor = 'Activo';

-- ==========================================
-- 7. TABLA DE ROLES (app interna, no MySQL roles)
-- ==========================================

CREATE TABLE IF NOT EXISTS roles (
    rol_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

INSERT IGNORE INTO roles (nombre) VALUES ('Admin'), ('Operador'), ('Auditor'), ('Cliente');

-- ==========================================
-- 8. TABLA DE USUARIOS (del sistema, no MySQL)
-- ==========================================

CREATE TABLE IF NOT EXISTS usuario (
    usuario_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(200) NOT NULL,
    rol_id INT NOT NULL,
    FOREIGN KEY (rol_id) REFERENCES roles(rol_id)
);

INSERT IGNORE INTO usuario (nombre, username, password, rol_id) VALUES 
('Administrador', 'admin_user', 'Admin#2025', 1),
('Operador', 'operador_user', 'Operador#2025', 2),
('Auditor', 'auditor_user', 'Auditor#2025', 3),
('Cliente', 'cliente_user', 'Cliente#2025', 4);