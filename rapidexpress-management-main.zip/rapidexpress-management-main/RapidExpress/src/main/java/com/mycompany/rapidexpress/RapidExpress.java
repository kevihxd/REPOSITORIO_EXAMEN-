package com.mycompany.rapidexpress;



import menus.menuGeneral;

public class RapidExpress {

    public static void main(String[] args) {
        menuGeneral menuGeneral = new menuGeneral();
        menuGeneral.iniciar();
    }
}
