/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import modelo.Rol;
import java.util.List;

/**
 *
 * @author PC
 */
public interface RolDAO {
    void insertar(Rol rol);

    List<Rol> listar();

    Rol buscarPorId(int id);

    void actualizar(Rol rol);

    void eliminar(int id);
}
