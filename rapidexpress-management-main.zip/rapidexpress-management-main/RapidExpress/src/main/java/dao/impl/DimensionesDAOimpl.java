/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import config.ConexionBD;
import dao.DimensionesDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Dimensiones;

/**
 *
 * @author camper
 */
public class DimensionesDAOimpl implements DimensionesDAO {
    @Override
    public void insertar(Dimensiones dim) {
        String sql = "INSERT INTO dimensiones (largo, ancho, alto) VALUES (?, ?, ?)";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDouble(1, dim.getLargo());
            ps.setDouble(2, dim.getAncho());
            ps.setDouble(3, dim.getAlto());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("[ERROR] insertando dimensiones: " + e.getMessage());
        }
    }

    @Override
    public List<Dimensiones> listar() {
        List<Dimensiones> lista = new ArrayList<>();
        String sql = "SELECT * FROM dimensiones";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Dimensiones(
                        rs.getInt("id_dimensiones"),
                        rs.getDouble("largo"),
                        rs.getDouble("ancho"),
                        rs.getDouble("alto")
                ));
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] listando dimensiones: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public Dimensiones buscarPorId(int id) {
        String sql = "SELECT * FROM dimensiones WHERE id_dimensiones=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Dimensiones(
                        rs.getInt("id_dimensiones"),
                        rs.getDouble("largo"),
                        rs.getDouble("ancho"),
                        rs.getDouble("alto")
                );
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] buscando dimensiones: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void actualizar(Dimensiones dim) {
        String sql = "UPDATE dimensiones SET largo=?, ancho=?, alto=? WHERE id_dimensiones=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDouble(1, dim.getLargo());
            ps.setDouble(2, dim.getAncho());
            ps.setDouble(3, dim.getAlto());
            ps.setInt(4, dim.getId());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("[ERROR] actualizando dimensiones: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM dimensiones WHERE id_dimensiones=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] eliminando dimensiones: " + e.getMessage());
        }
    }
}
