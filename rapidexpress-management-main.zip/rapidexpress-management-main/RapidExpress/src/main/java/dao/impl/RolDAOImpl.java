/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import config.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Rol;

/**
 *
 * @author PC
 */
public class RolDAOImpl {
    
    
    public void insertar(Rol rol) {
        String sql = "INSERT INTO roles (nombre, descripcion) VALUES (?, ?)";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, rol.getNombre());
            
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al insertar rol: " + e.getMessage());
        }
    }

    
    public List<Rol> listar() {
        List<Rol> lista = new ArrayList<>();
        String sql = "SELECT rol_id, nombre, descripcion FROM roles";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Rol rol = new Rol();
                rol.setRolId(rs.getInt("rol_id"));
                rol.setNombre(rs.getString("nombre"));                ;
                lista.add(rol);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar roles: " + e.getMessage());
        }

        return lista;
    }

    
    public Rol buscarPorId(int id) {
        Rol rol = null;
        String sql = "SELECT rol_id, nombre, descripcion FROM roles WHERE rol_id = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    rol = new Rol();
                    rol.setRolId(rs.getInt("rol_id"));
                    rol.setNombre(rs.getString("nombre"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al buscar rol: " + e.getMessage());
        }

        return rol;
    }

    
    public void actualizar(Rol rol) {
        String sql = "UPDATE roles SET nombre = ?, descripcion = ? WHERE rol_id = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, rol.getNombre());
            stmt.setInt(2, rol.getRolId());
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al actualizar rol: " + e.getMessage());
        }
    }

    
    public void eliminar(int id) {
        String sql = "DELETE FROM roles WHERE rol_id = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al eliminar rol: " + e.getMessage());
        }
    }
}
