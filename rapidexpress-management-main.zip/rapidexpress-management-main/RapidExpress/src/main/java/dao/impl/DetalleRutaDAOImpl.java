/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import config.ConexionBD;
import dao.DetalleRutaDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import modelo.DetalleRuta;
import modelo.enums.EstadoDetalleRuta;

/**
 *
 * @author camper
 */
public class DetalleRutaDAOImpl implements DetalleRutaDAO {
    public void insertar(DetalleRuta detalle) {
        String sql = "INSERT INTO detalle_ruta (id_ruta, id_paquete, fecha_asignacion, estado_detalle) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, detalle.getIdRuta());
            ps.setInt(2, detalle.getIdPaquete());
            ps.setTimestamp(3, Timestamp.valueOf(detalle.getFechaAsignacion()));
            ps.setString(4, detalle.getEstado().name());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("[ERROR] insertando detalle ruta: " + e.getMessage());
        }
    }

    @Override
    public List<DetalleRuta> listar() {
        List<DetalleRuta> lista = new ArrayList<>();
        String sql = "SELECT * FROM detalle_ruta";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new DetalleRuta(
                        rs.getInt("id_detalle"),
                        rs.getInt("id_ruta"),
                        rs.getInt("id_paquete"),
                        rs.getTimestamp("fecha_asignacion").toLocalDateTime(),
                        rs.getTimestamp("fecha_entrega") != null ? rs.getTimestamp("fecha_entrega").toLocalDateTime() : null,
                        EstadoDetalleRuta.valueOf(rs.getString("estado_detalle"))
                ));
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] listando detalle rutas: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public DetalleRuta buscarPorId(int id) {
        String sql = "SELECT * FROM detalle_ruta WHERE id_detalle=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new DetalleRuta(
                        rs.getInt("id_detalle"),
                        rs.getInt("id_ruta"),
                        rs.getInt("id_paquete"),
                        rs.getTimestamp("fecha_asignacion").toLocalDateTime(),
                        rs.getTimestamp("fecha_entrega") != null ? rs.getTimestamp("fecha_entrega").toLocalDateTime() : null,
                        EstadoDetalleRuta.valueOf(rs.getString("estado_detalle"))
                );
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] buscando detalle ruta: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void actualizar(DetalleRuta detalle) {
        String sql = "UPDATE detalle_ruta SET id_ruta=?, id_paquete=?, fecha_asignacion=?, fecha_entrega=?, estado_detalle=? WHERE id_detalle=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, detalle.getIdRuta());
            ps.setInt(2, detalle.getIdPaquete());
            ps.setTimestamp(3, Timestamp.valueOf(detalle.getFechaAsignacion()));
            if (detalle.getFechaEntrega() != null) {
                ps.setTimestamp(4, Timestamp.valueOf(detalle.getFechaEntrega()));
            } else {
                ps.setNull(4, Types.TIMESTAMP);
            }
            ps.setString(5, detalle.getEstado().name());
            ps.setInt(6, detalle.getIdDetalle());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("[ERROR] actualizando detalle ruta: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM detalle_ruta WHERE id_detalle=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] eliminando detalle ruta: " + e.getMessage());
        }
    }
}
