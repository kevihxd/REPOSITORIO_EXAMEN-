/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import modelo.Usuario;
/**
 *
 * @author camper
 */
public class UsuarioDAOImpl {
         private final Connection connection;

    public UsuarioDAOImpl(Connection connection) {
        this.connection = connection;
    }

    public void insertar(Usuario usuario) {
        String sql = "INSERT INTO usuario (nombre, username, password, rol_id) VALUES (?,?,?,?)";
        try(PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNombre());
            stmt.setString(2, usuario.getUsername());
            stmt.setString(3, usuario.getPassword());
            stmt.setInt(4, usuario.getRolId());
            stmt.executeUpdate();
        } catch(Exception e) {
            throw new RuntimeException("Error al insertar usuario", e);
        }
    }

    public Usuario buscarPorUsername(String username) {
        String sql = "SELECT * FROM usuario WHERE username = ?";
        try(PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if(rs.next()) {
                return new Usuario(
                    rs.getInt("usuario_id"),
                    rs.getString("nombre"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getInt("rol_id")
                );
            }
            return null;
        } catch(Exception e) {
            throw new RuntimeException("Error al buscar usuario", e);
        }
    }
}
