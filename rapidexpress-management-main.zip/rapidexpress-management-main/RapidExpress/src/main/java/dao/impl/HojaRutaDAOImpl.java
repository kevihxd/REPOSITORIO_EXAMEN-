/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;


import config.ConexionBD;
import dao.HojaRutaDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import modelo.HojaRuta;

/**
 *
 * @author camper
 */
public class HojaRutaDAOImpl {
    public void insertar(HojaRuta hoja) {
        String sql = "INSERT INTO hoja_ruta (id_ruta, id_vehiculo, id_conductor, fecha_creacion) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, hoja.getIdRuta());
            ps.setInt(2, hoja.getIdVehiculo());
            ps.setInt(3, hoja.getIdConductor());
            ps.setTimestamp(4, Timestamp.valueOf(hoja.getFechaCreacion()));

            ps.executeUpdate();

            // Obtener ID generado
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                hoja.setId(rs.getInt(1));
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] insertando hoja de ruta: " + e.getMessage());
        }
    }

    
    public List<HojaRuta> listar() {
        List<HojaRuta> lista = new ArrayList<>();
        String sql = "SELECT * FROM hoja_ruta";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new HojaRuta(
                        rs.getInt("id_hoja"),
                        rs.getInt("id_ruta"),
                        rs.getInt("id_vehiculo"),
                        rs.getInt("id_conductor"),
                        rs.getTimestamp("fecha_creacion").toLocalDateTime(),
                        null 
                ));
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] listando hojas de ruta: " + e.getMessage());
        }
        return lista;
    }

    
    public HojaRuta buscarPorId(int id) {
        String sql = "SELECT * FROM hoja_ruta WHERE id_hoja=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new HojaRuta(
                        rs.getInt("id_hoja"),
                        rs.getInt("id_ruta"),
                        rs.getInt("id_vehiculo"),
                        rs.getInt("id_conductor"),
                        rs.getTimestamp("fecha_creacion").toLocalDateTime(),
                        null
                );
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] buscando hoja de ruta: " + e.getMessage());
        }
        return null;
    }

    
    public void actualizar(HojaRuta hoja) {
        String sql = "UPDATE hoja_ruta SET id_ruta=?, id_vehiculo=?, id_conductor=?, fecha_creacion=? WHERE id_hoja=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, hoja.getIdRuta());
            ps.setInt(2, hoja.getIdVehiculo());
            ps.setInt(3, hoja.getIdConductor());
            ps.setTimestamp(4, Timestamp.valueOf(hoja.getFechaCreacion()));
            ps.setInt(5, hoja.getId());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("[ERROR] actualizando hoja de ruta: " + e.getMessage());
        }
    }

    
    public void eliminar(int id) {
        String sql = "DELETE FROM hoja_ruta WHERE id_hoja=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] eliminando hoja de ruta: " + e.getMessage());
        }
    }
}
