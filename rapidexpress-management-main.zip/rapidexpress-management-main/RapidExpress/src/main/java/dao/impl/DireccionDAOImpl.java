/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import config.ConexionBD;
import dao.DireccionDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Direccion;

/**
 *
 * @author camper
 */
public class DireccionDAOImpl implements DireccionDAO {
    
    @Override
    public void insertar(Direccion direccion) {
        String sql = "INSERT INTO direcciones (calle, ciudad, departamento, pais, codigo_postal) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, direccion.getCalle());
            ps.setString(2, direccion.getCiudad());
            ps.setString(3, direccion.getDepartamento());
            ps.setString(4, direccion.getPais());
            ps.setString(5, direccion.getCodigoPostal());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("[ERROR] insertando dirección: " + e.getMessage());
        }
    }

    @Override
    public List<Direccion> listar() {
        List<Direccion> lista = new ArrayList<>();
        String sql = "SELECT * FROM direcciones";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Direccion(
                        rs.getInt("id_direccion"),
                        rs.getString("calle"),
                        rs.getString("ciudad"),
                        rs.getString("departamento"),
                        rs.getString("pais"),
                        rs.getString("codigo_postal")
                ));
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] listando direcciones: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public Direccion buscarPorId(int id) {
        String sql = "SELECT * FROM direcciones WHERE id_direccion=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Direccion(
                        rs.getInt("id_direccion"),
                        rs.getString("calle"),
                        rs.getString("ciudad"),
                        rs.getString("departamento"),
                        rs.getString("pais"),
                        rs.getString("codigo_postal")
                );
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] buscando dirección: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void actualizar(Direccion direccion) {
        String sql = "UPDATE direcciones SET calle=?, ciudad=?, departamento=?, pais=?, codigo_postal=? WHERE id_direccion=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, direccion.getCalle());
            ps.setString(2, direccion.getCiudad());
            ps.setString(3, direccion.getDepartamento());
            ps.setString(4, direccion.getPais());
            ps.setString(5, direccion.getCodigoPostal());
            ps.setInt(6, direccion.getId());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("[ERROR] actualizando dirección: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM direcciones WHERE id_direccion=?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] eliminando dirección: " + e.getMessage());
        }
    }
}
