/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;


import config.ConexionBD;
import dao.VehiculoDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Vehiculo;
import modelo.enums.EstadoVehiculo;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author camper
 */
public class VehiculoDAOImpl implements  VehiculoDAO{
    public void insertar(Vehiculo vehiculo) {
        String sql = "INSERT INTO vehiculos (placa, marca, modelo, anio_fabricacion, capacidad_kg, estado_vehiculo) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, vehiculo.getPlaca());
            ps.setString(2, vehiculo.getMarca());
            ps.setString(3, vehiculo.getModelo());
            ps.setInt(4, vehiculo.getAnioFabricacion());
            ps.setInt(5, vehiculo.getCapacidadKg());
            ps.setString(6, vehiculo.getEstadoVehiculo().name().replace("_", " "));

            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] insertando vehículo: " + e.getMessage());
        }
    }

    
    public List<Vehiculo> listar() {
        List<Vehiculo> lista = new ArrayList<>();
        String sql = "SELECT * FROM vehiculos";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                EstadoVehiculo estado = EstadoVehiculo.valueOf(
                        rs.getString("estado_vehiculo").replace(" ", "_")
                );

                Vehiculo v = new Vehiculo(
                        rs.getInt("id_vehiculo"),
                        rs.getString("placa"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getInt("anio_fabricacion"),
                        rs.getInt("capacidad_kg"),
                        estado,
                        rs.getString("created_at")
                );

                lista.add(v);
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] listando vehículos: " + e.getMessage());
        }
        return lista;
    }

    
    public Vehiculo buscarPorId(int id) {
        String sql = "SELECT * FROM vehiculos WHERE id_vehiculo = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                EstadoVehiculo estado = EstadoVehiculo.valueOf(
                        rs.getString("estado_vehiculo").replace(" ", "_")
                );

                return new Vehiculo(
                        rs.getInt("id_vehiculo"),
                        rs.getString("placa"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getInt("anio_fabricacion"),
                        rs.getInt("capacidad_kg"),
                        estado,
                        rs.getString("created_at")
                );
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] buscando vehículo ID: " + e.getMessage());
        }

        return null;
    }

    
    public void actualizar(Vehiculo vehiculo) {
        String sql = "UPDATE vehiculos SET placa=?, marca=?, modelo=?, anio_fabricacion=?, capacidad_kg=?, estado_vehiculo=? "
                   + "WHERE id_vehiculo=?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, vehiculo.getPlaca());
            ps.setString(2, vehiculo.getMarca());
            ps.setString(3, vehiculo.getModelo());
            ps.setInt(4, vehiculo.getAnioFabricacion());
            ps.setInt(5, vehiculo.getCapacidadKg());
            ps.setString(6, vehiculo.getEstadoVehiculo().name().replace("_", " "));
            ps.setInt(7, vehiculo.getIdVehiculo());

            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] actualizando vehículo: " + e.getMessage());
        }
    }
    
    
    public void eliminar(int id) {
        String sql = "DELETE FROM vehiculos WHERE id_vehiculo = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] eliminando vehículo: " + e.getMessage());
        }
    }
}
