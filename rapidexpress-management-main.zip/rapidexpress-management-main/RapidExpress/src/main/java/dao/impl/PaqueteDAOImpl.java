/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import dao.PaqueteDAO;
import modelo.Paquete;
import modelo.DatosPersona;
import config.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaqueteDAOImpl implements PaqueteDAO {

    private final Connection conexion;

    public PaqueteDAOImpl() {
        this.conexion = ConexionBD.conectar();
    }

    private DatosPersona mapPersona(ResultSet rs, String prefix) throws SQLException {
        return new DatosPersona(
            rs.getInt(prefix + "_id"),
            rs.getString(prefix + "_nombre"),
            rs.getString(prefix + "_apellido"),
            rs.getString(prefix + "_telefono"),
            rs.getString(prefix + "_email"),
            rs.getString(prefix + "_direccion")
        );
    }

    private Paquete mapPaquete(ResultSet rs) throws SQLException {
        DatosPersona remitente = mapPersona(rs, "rem");
        DatosPersona destinatario = mapPersona(rs, "dest");

        return new Paquete(
            rs.getInt("id_paquete"),
            rs.getString("Numero_Guia"),
            rs.getString("descripcion"),
            rs.getDouble("peso"),
            rs.getString("dimensiones"),
            remitente,
            destinatario,
            rs.getString("direccion_origen"),
            rs.getString("direccion_destino"),
            rs.getString("estado_paquete"),
            rs.getString("created_at")
        );
    }

    @Override
    public boolean insertar(Paquete paquete) {
        String sql = """
            INSERT INTO paquetes (Numero_Guia, descripcion, peso, dimensiones, 
            remitente_id, destinatario_id, direccion_origen, direccion_destino)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, paquete.getNumero_Guia());
            ps.setString(2, paquete.getDescripcion());
            ps.setDouble(3, paquete.getPeso());
            ps.setString(4, paquete.getDimensiones());
            ps.setInt(5, paquete.getRemitente_id().getId_persona());
            ps.setInt(6, paquete.getDestinatario_id().getId_persona());
            ps.setString(7, paquete.getDireccion_origen());
            ps.setString(8, paquete.getDireccion_destino());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error insertando paquete: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean actualizar(Paquete paquete) {
        String sql = """
            UPDATE paquetes SET
            Numero_Guia=?, descripcion=?, peso=?, dimensiones=?,
            remitente_id=?, destinatario_id=?, direccion_origen=?,
            direccion_destino=?, estado_paquete=?
            WHERE id_paquete=?
        """;

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, paquete.getNumero_Guia());
            ps.setString(2, paquete.getDescripcion());
            ps.setDouble(3, paquete.getPeso());
            ps.setString(4, paquete.getDimensiones());
            ps.setInt(5, paquete.getRemitente_id().getId_persona());
            ps.setInt(6, paquete.getDestinatario_id().getId_persona());
            ps.setString(7, paquete.getDireccion_origen());
            ps.setString(8, paquete.getDireccion_destino());
            ps.setString(9, paquete.getEstado_paquete());
            ps.setInt(10, paquete.getId_paquete());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizando paquete: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean actualizarEstado(int idPaquete, String nuevoEstado) {
        String sql = "UPDATE paquetes SET estado_paquete=? WHERE id_paquete=?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, idPaquete);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizando estado: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean eliminar(int idPaquete) {
        String sql = "DELETE FROM paquetes WHERE id_paquete=?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPaquete);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error eliminando paquete: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Paquete obtenerPorId(int idPaquete) {
        String sql = """
            SELECT p.*, 
            rem.id_persona AS rem_id, rem.nombre AS rem_nombre, rem.apellido AS rem_apellido,
            rem.telefono AS rem_telefono, rem.email AS rem_email, rem.direccion AS rem_direccion,
            dest.id_persona AS dest_id, dest.nombre AS dest_nombre, dest.apellido AS dest_apellido,
            dest.telefono AS dest_telefono, dest.email AS dest_email, dest.direccion AS dest_direccion
            FROM paquetes p
            JOIN personas rem ON rem.id_persona = p.remitente_id
            JOIN personas dest ON dest.id_persona = p.destinatario_id
            WHERE id_paquete=?
        """;

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPaquete);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) return mapPaquete(rs);

        } catch (SQLException e) {
            System.out.println("Error obteniendo paquete: " + e.getMessage());
        }

        return null;
    }

    @Override
    public Paquete obtenerPorGuia(String guia) {
        String sql = """
            SELECT p.*, 
            rem.id_persona AS rem_id, rem.nombre AS rem_nombre, rem.apellido AS rem_apellido,
            rem.telefono AS rem_telefono, rem.email AS rem_email, rem.direccion AS rem_direccion,
            dest.id_persona AS dest_id, dest.nombre AS dest_nombre, dest.apellido AS dest_apellido,
            dest.telefono AS dest_telefono, dest.email AS dest_email, dest.direccion AS dest_direccion
            FROM paquetes p
            JOIN personas rem ON rem.id_persona = p.remitente_id
            JOIN personas dest ON dest.id_persona = p.destinatario_id
            WHERE Numero_Guia=?
        """;

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, guia);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) return mapPaquete(rs);

        } catch (SQLException e) {
            System.out.println("Error paquete por guía: " + e.getMessage());
        }

        return null;
    }
    
    @Override
   public List<Paquete> listarPorCliente(int clienteId) {
    List<Paquete> lista = new ArrayList<>();

    String sql = """
        SELECT p.*, 
        rem.id_persona AS rem_id, rem.nombre AS rem_nombre, rem.apellido AS rem_apellido,
        rem.telefono AS rem_telefono, rem.email AS rem_email, rem.direccion AS rem_direccion,
        dest.id_persona AS dest_id, dest.nombre AS dest_nombre, dest.apellido AS dest_apellido,
        dest.telefono AS dest_telefono, dest.email AS dest_email, dest.direccion AS dest_direccion
        FROM paquetes p
        JOIN personas rem ON rem.id_persona = p.remitente_id
        JOIN personas dest ON dest.id_persona = p.destinatario_id
        WHERE p.remitente_id = ? OR p.destinatario_id = ?
        ORDER BY p.id_paquete DESC
    """;

    try (PreparedStatement ps = conexion.prepareStatement(sql)) {
        ps.setInt(1, clienteId);
        ps.setInt(2, clienteId);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            lista.add(mapPaquete(rs));
        }

    } catch (SQLException e) {
        System.out.println("Error listando paquetes por cliente: " + e.getMessage());
    }

    return lista;
}

    @Override
    public List<Paquete> listarTodos() {
        List<Paquete> lista = new ArrayList<>();

        String sql = """
            SELECT p.*, 
            rem.id_persona AS rem_id, rem.nombre AS rem_nombre, rem.apellido AS rem_apellido,
            rem.telefono AS rem_telefono, rem.email AS rem_email, rem.direccion AS rem_direccion,
            dest.id_persona AS dest_id, dest.nombre AS dest_nombre, dest.apellido AS dest_apellido,
            dest.telefono AS dest_telefono, dest.email AS dest_email, dest.direccion AS dest_direccion
            FROM paquetes p
            JOIN personas rem ON rem.id_persona = p.remitente_id
            JOIN personas dest ON dest.id_persona = p.destinatario_id
            ORDER BY p.id_paquete DESC
        """;

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) lista.add(mapPaquete(rs));

        } catch (SQLException e) {
            System.out.println("Error listando paquetes: " + e.getMessage());
        }

        return lista;
    }
    
    
}

