/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import dao.PersonaDAO;
import modelo.DatosPersona;
import config.ConexionBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */

public class PersonaDAOImpl implements PersonaDAO {

    private Connection conexion;

    public PersonaDAOImpl() {
        conexion = ConexionBD.conectar();
    }

    @Override
    public boolean insertar(DatosPersona persona) {
        String sql = "INSERT INTO personas (nombre, apellido, telefono, email, direccion) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, persona.getNombre());
            ps.setString(2, persona.getApellido());
            ps.setString(3, persona.getTelefono());
            ps.setString(4, persona.getEmail());
            ps.setString(5, persona.getDireccion());
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error insertando persona: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean actualizar(DatosPersona persona) {
        String sql = "UPDATE personas SET nombre = ?, apellido = ?, telefono = ?, email = ?, direccion = ? "
                   + "WHERE id_persona = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, persona.getNombre());
            ps.setString(2, persona.getApellido());
            ps.setString(3, persona.getTelefono());
            ps.setString(4, persona.getEmail());
            ps.setString(5, persona.getDireccion());
            ps.setInt(6, persona.getId_persona());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error actualizando persona: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean eliminar(int idPersona) {
        String sql = "DELETE FROM personas WHERE id_persona = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPersona);
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error eliminando persona: " + e.getMessage());
            return false;
        }
    }

    @Override
    public DatosPersona obtenerPorId(int idPersona) {
        String sql = "SELECT * FROM personas WHERE id_persona = ?";
        DatosPersona persona = null;

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPersona);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                persona = new DatosPersona(
                    rs.getInt("id_persona"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("telefono"),
                    rs.getString("email"),
                    rs.getString("direccion")
                );
            }

        } catch (SQLException e) {
            System.out.println("Error obteniendo persona: " + e.getMessage());
        }

        return persona;
    }

    @Override
    public List<DatosPersona> listarTodos() {
        String sql = "SELECT * FROM personas";
        List<DatosPersona> lista = new ArrayList<>();

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                DatosPersona persona = new DatosPersona(
                    rs.getInt("id_persona"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("telefono"),
                    rs.getString("email"),
                    rs.getString("direccion")
                );
                lista.add(persona);
            }

        } catch (SQLException e) {
            System.out.println("Error listando personas: " + e.getMessage());
        }

        return lista;
    }
}