/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;


import config.ConexionBD;
import dao.RutaDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import modelo.Ruta;
import modelo.enums.EstadoRuta;

/**
 *
 * @author camper
 */
public class RutaDAOImpl implements RutaDAO  {
    
    public void insertar(Ruta ruta) {
        String sql = "INSERT INTO rutas (id_vehiculo, id_conductor, estado_ruta, fecha_inicio, fecha_fin) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ruta.getVehiculoId());
            ps.setInt(2, ruta.getConductorId());
            ps.setString(3, ruta.getEstado().name().replace("_", " "));
            ps.setTimestamp(4, Timestamp.valueOf(ruta.getFechaInicio()));
            if (ruta.getFechaFin() != null) {
                ps.setTimestamp(5, Timestamp.valueOf(ruta.getFechaFin()));
            } else {
                ps.setNull(5, Types.TIMESTAMP);
            }

            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] insertando ruta: " + e.getMessage());
        }
    }

    @Override
    public List<Ruta> listar() {
        List<Ruta> lista = new ArrayList<>();
        String sql = "SELECT * FROM rutas";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadoRuta estado = EstadoRuta.valueOf(rs.getString("estado_ruta").toUpperCase().replace(" ", "_"));


                LocalDateTime fechaInicio = rs.getTimestamp("fecha_inicio").toLocalDateTime();
                Timestamp tsFin = rs.getTimestamp("fecha_fin");
                LocalDateTime fechaFin = tsFin != null ? tsFin.toLocalDateTime() : null;

                Ruta ruta = new Ruta(
                        rs.getInt("id_ruta"),
                        rs.getInt("id_vehiculo"),
                        rs.getInt("id_conductor"),
                        estado,
                        fechaInicio,
                        fechaFin
                );

                lista.add(ruta);
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] listando rutas: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public Ruta buscarPorId(int id) {
        String sql = "SELECT * FROM rutas WHERE id_ruta = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                EstadoRuta estado = EstadoRuta.valueOf(rs.getString("estado_ruta").replace(" ", "_"));

                LocalDateTime fechaInicio = rs.getTimestamp("fecha_inicio").toLocalDateTime();
                Timestamp tsFin = rs.getTimestamp("fecha_fin");
                LocalDateTime fechaFin = tsFin != null ? tsFin.toLocalDateTime() : null;

                return new Ruta(
                        rs.getInt("id_ruta"),
                        rs.getInt("id_vehiculo"),
                        rs.getInt("id_conductor"),
                        estado,
                        fechaInicio,
                        fechaFin
                );
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] buscando ruta ID: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void actualizar(Ruta ruta) {
        String sql = "UPDATE rutas SET id_vehiculo=?, id_conductor=?, estado_ruta=?, fecha_inicio=?, fecha_fin=? "
                   + "WHERE id_ruta=?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ruta.getVehiculoId());
            ps.setInt(2, ruta.getConductorId());
            ps.setString(3, ruta.getEstado().name().replace("_", " "));
            ps.setTimestamp(4, Timestamp.valueOf(ruta.getFechaInicio()));
            if (ruta.getFechaFin() != null) {
                ps.setTimestamp(5, Timestamp.valueOf(ruta.getFechaFin()));
            } else {
                ps.setNull(5, Types.TIMESTAMP);
            }
            ps.setInt(6, ruta.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] actualizando ruta: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM rutas WHERE id_ruta = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] eliminando ruta: " + e.getMessage());
        }
    }
}
