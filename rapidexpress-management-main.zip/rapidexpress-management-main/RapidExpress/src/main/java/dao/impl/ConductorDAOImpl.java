/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import config.ConexionBD;
import dao.ConductorDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modelo.Conductor;
import modelo.enums.EstadoConductor;

/**
 *
 * @author camper
 */

public class ConductorDAOImpl implements ConductorDAO {


    public void insertar(Conductor conductor) {
        String sql = "INSERT INTO conductores " +
            "(identificacion, nombre, apellido, tipo_licencia, telefono, estado_conductor) " +
            "VALUES (?, ?, ?, ?, ?, ?)";


        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, conductor.getIdentificacion());
            stmt.setString(2, conductor.getNombre());
            stmt.setString(3, conductor.getApellido());
            stmt.setString(4, conductor.getTipoLicencia());
            stmt.setString(5, conductor.getTelefono());
            stmt.setString(6, conductor.getEstado().name());

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al insertar conductor: " + e.getMessage());
        }
    }

    
    public List<Conductor> listar() {
        List<Conductor> lista = new ArrayList<>();
        String sql = "SELECT * FROM conductores";

        try (Connection conn = ConexionBD.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(mapearConductor(rs));
            }

        } catch (SQLException e) {
            System.out.println("Error al listar conductores: " + e.getMessage());
        }

        return lista;
    }

    @Override
    public Conductor buscarPorId(int id) {
        String sql = "SELECT * FROM conductores WHERE id_conductor = ?";
        Conductor conductor = null;

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                conductor = mapearConductor(rs);
            }

        } catch (SQLException e) {
            System.out.println("Error al buscar conductor: " + e.getMessage());
        }

        return conductor;
    }

    
    public void actualizar(Conductor conductor) {
        String sql = "UPDATE conductores SET " +
            "identificacion = ?, nombre = ?, apellido = ?, " +
            "tipo_licencia = ?, telefono = ?, estado_conductor = ? " +
            "WHERE id_conductor = ?";


        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, conductor.getIdentificacion());
            stmt.setString(2, conductor.getNombre());
            stmt.setString(3, conductor.getApellido());
            stmt.setString(4, conductor.getTipoLicencia());
            stmt.setString(5, conductor.getTelefono());
            stmt.setString(6, conductor.getEstado().name());
            stmt.setInt(7, conductor.getIdConductor());

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al actualizar conductor: " + e.getMessage());
        }
    }

    
    public void eliminar(int id) {
        String sql = "DELETE FROM conductores WHERE id_conductor = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al eliminar conductor: " + e.getMessage());
        }
    }

    private Conductor mapearConductor(ResultSet rs) throws SQLException {
        Conductor c = new Conductor();

        c.setIdConductor(rs.getInt("id_conductor"));
        c.setIdentificacion(rs.getString("identificacion"));
        c.setNombre(rs.getString("nombre"));
        c.setApellido(rs.getString("apellido"));
        c.setTipoLicencia(rs.getString("tipo_licencia"));
        c.setTelefono(rs.getString("telefono"));

        // Mapear estado_conductor al enum
        String estadoStr = rs.getString("estado_conductor");
        try {
            c.setEstado(EstadoConductor.valueOf(estadoStr));
        } catch (Exception e) {
            c.setEstado(null);
        }

        return c;
    }


}