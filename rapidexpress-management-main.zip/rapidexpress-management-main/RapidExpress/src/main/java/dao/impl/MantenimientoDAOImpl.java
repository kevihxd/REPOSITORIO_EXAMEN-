/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.impl;

import config.ConexionBD;
import dao.MantenimientoDAO;
import dao.VehiculoDAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import modelo.Mantenimiento;
import modelo.Vehiculo;

public class MantenimientoDAOImpl implements MantenimientoDAO {

    private final VehiculoDAO vehiculoDAO = new VehiculoDAOImpl();

    @Override
    public void insertar(Mantenimiento m) {
        String sql = "INSERT INTO historial_mantenimiento "
                + "(id_vehiculo, fecha_mantenimiento, descripcion, tipo, costo, realizado_por) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, m.getId_vehiculo().getIdVehiculo());
            ps.setTimestamp(2, new Timestamp(m.getFecha_mantenimiento().getTime()));
            ps.setString(3, m.getDescripcion());
            ps.setString(4, m.getTipo());
            ps.setDouble(5, m.getCosto());
            ps.setString(6, m.getRealizado_por());

            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] insertando mantenimiento: " + e.getMessage());
        }
    }

    @Override
    public void actualizar(Mantenimiento m) {
        String sql = "UPDATE historial_mantenimiento SET id_vehiculo=?, fecha_mantenimiento=?, "
                + "descripcion=?, tipo=?, costo=?, realizado_por=? WHERE id_mantenimiento=?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, m.getId_vehiculo().getIdVehiculo());
            ps.setTimestamp(2, new Timestamp(m.getFecha_mantenimiento().getTime()));
            ps.setString(3, m.getDescripcion());
            ps.setString(4, m.getTipo());
            ps.setDouble(5, m.getCosto());
            ps.setString(6, m.getRealizado_por());
            ps.setInt(7, m.getId_mantenimiento());

            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] actualizando mantenimiento: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM historial_mantenimiento WHERE id_mantenimiento=?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("[ERROR] eliminando mantenimiento: " + e.getMessage());
        }
    }

    @Override
    public Mantenimiento buscarPorId(int id) {
        String sql = "SELECT * FROM historial_mantenimiento WHERE id_mantenimiento=?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Vehiculo v = vehiculoDAO.buscarPorId(rs.getInt("id_vehiculo"));

                return new Mantenimiento(
                        rs.getInt("id_mantenimiento"),
                        v,
                        new Date(rs.getTimestamp("fecha_mantenimiento").getTime()),
                        rs.getString("descripcion"),
                        rs.getString("tipo"),
                        rs.getDouble("costo"),
                        rs.getString("realizado_por")
                );
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] buscando mantenimiento: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Mantenimiento> listar() {
        List<Mantenimiento> lista = new ArrayList<>();
        String sql = "SELECT * FROM historial_mantenimiento";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Vehiculo v = vehiculoDAO.buscarPorId(rs.getInt("id_vehiculo"));

                lista.add(new Mantenimiento(
                        rs.getInt("id_mantenimiento"),
                        v,
                        new Date(rs.getTimestamp("fecha_mantenimiento").getTime()),
                        rs.getString("descripcion"),
                        rs.getString("tipo"),
                        rs.getDouble("costo"),
                        rs.getString("realizado_por")
                ));
            }

        } catch (SQLException e) {
            System.out.println("[ERROR] listando mantenimientos: " + e.getMessage());
        }
        return lista;
    }
}

