/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import modelo.DetalleRuta;
import java.util.List;

/**
 *
 * @author camper
 */
public interface DetalleRutaDAO {
    void insertar(DetalleRuta detalle);
    List<DetalleRuta> listar();
    DetalleRuta buscarPorId(int id);
    void actualizar(DetalleRuta detalle);
    void eliminar(int id);
}
