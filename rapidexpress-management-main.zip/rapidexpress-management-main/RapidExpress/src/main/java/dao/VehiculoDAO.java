/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.List;
import modelo.Vehiculo;
/**
 *
 * @author camper
 */
public interface VehiculoDAO {
    void insertar(Vehiculo vehiculo);

    List<Vehiculo> listar();

    Vehiculo buscarPorId(int id);

    void actualizar(Vehiculo vehiculo);

    void eliminar(int id);
}
