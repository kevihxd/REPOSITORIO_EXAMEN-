/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import modelo.Paquete;
import java.util.List;

public interface PaqueteDAO {

    boolean insertar(Paquete paquete);

    boolean actualizar(Paquete paquete);

    boolean actualizarEstado(int idPaquete, String nuevoEstado);

    boolean eliminar(int idPaquete);

    Paquete obtenerPorId(int idPaquete);

    Paquete obtenerPorGuia(String numeroGuia);

    List<Paquete> listarTodos();
    
    List<Paquete> listarPorCliente(int clienteId);
    
}
