/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.List;
import modelo.Ruta;

/**
 *
 * @author camper
 */
public interface RutaDAO {
    void insertar(Ruta ruta);
    List<Ruta> listar();
    Ruta buscarPorId(int id);
    void actualizar(Ruta ruta);
    void eliminar(int id);
}
