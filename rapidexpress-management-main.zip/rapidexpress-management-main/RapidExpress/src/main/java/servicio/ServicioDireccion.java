/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import dao.DireccionDAO;
import dao.impl.DireccionDAOImpl;
import java.util.List;
import modelo.Direccion;

/**
 *
 * @author camper
 */
public class ServicioDireccion {
    private DireccionDAO direccionDAO;

    public ServicioDireccion() {
        this.direccionDAO = new DireccionDAOImpl();
    }

    public void agregarDireccion(Direccion direccion) {
        direccionDAO.insertar(direccion);
    }

    public void actualizarDireccion(Direccion direccion) {
        direccionDAO.actualizar(direccion);
    }

    public void eliminarDireccion(int id) {
        direccionDAO.eliminar(id);
    }

    public Direccion buscarDireccion(int id) {
        return direccionDAO.buscarPorId(id);
    }

    public List<Direccion> listarDirecciones() {
        return direccionDAO.listar();
    }
}
