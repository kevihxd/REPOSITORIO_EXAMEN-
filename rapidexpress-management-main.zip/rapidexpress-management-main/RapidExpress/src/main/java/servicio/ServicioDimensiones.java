/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;


import dao.DimensionesDAO;
import dao.impl.DimensionesDAOimpl;
import java.util.List;
import modelo.Dimensiones;

/**
 *
 * @author camper
 */
public class ServicioDimensiones {
    private DimensionesDAO dimensionesDAO;

    public ServicioDimensiones() {
        this.dimensionesDAO = new DimensionesDAOimpl();
    }

    public void agregarDimensiones(Dimensiones dim) {
        dimensionesDAO.insertar(dim);
    }

    public void actualizarDimensiones(Dimensiones dim) {
        dimensionesDAO.actualizar(dim);
    }

    public void eliminarDimensiones(int id) {
        dimensionesDAO.eliminar(id);
    }

    public Dimensiones buscarDimensiones(int id) {
        return dimensionesDAO.buscarPorId(id);
    }

    public List<Dimensiones> listarDimensiones() {
        return dimensionesDAO.listar();
    }
}
