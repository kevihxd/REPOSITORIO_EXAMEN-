/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;


import dao.RutaDAO;
import dao.impl.RutaDAOImpl;
import java.util.List;
import modelo.Ruta;
import modelo.enums.EstadoRuta;

/**
 *
 * @author camper
 */
public class ServicioRutas {
    private RutaDAO rutaDAO = new RutaDAOImpl();

    // Crear una ruta nueva
    public void crearRuta(int vehiculoId, int conductorId) {
        Ruta ruta = new Ruta();
        ruta.setVehiculoId(vehiculoId);
        ruta.setConductorId(conductorId);
        ruta.setEstado(EstadoRuta.EN_CURSO); 
        ruta.setFechaInicio(java.time.LocalDateTime.now());
        rutaDAO.insertar(ruta);
    }

    // Listar todas las rutas
    public List<Ruta> listarRutas() {
        return rutaDAO.listar();
    }

    // Buscar ruta por ID
    public Ruta obtenerRutaPorId(int id) {
        return rutaDAO.buscarPorId(id);
    }

    // Actualizar ruta 
    public void actualizarRuta(Ruta ruta) {
        rutaDAO.actualizar(ruta);
    }

    // Finalizar una ruta 
    public void finalizarRuta(int idRuta) {
        Ruta ruta = rutaDAO.buscarPorId(idRuta);
        if (ruta != null) {
            ruta.setEstado(EstadoRuta.FINALIZADA);
            ruta.setFechaFin(java.time.LocalDateTime.now());
            rutaDAO.actualizar(ruta);
        } else {
            System.out.println("[ERROR] Ruta no encontrada con ID " + idRuta);
        }
    }

    // Eliminar una ruta
    public void eliminarRuta(int idRuta) {
        rutaDAO.eliminar(idRuta);
    }
}
