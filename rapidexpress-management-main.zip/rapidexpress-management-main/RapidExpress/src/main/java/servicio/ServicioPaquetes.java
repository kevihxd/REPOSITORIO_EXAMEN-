/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import dao.PaqueteDAO;
import dao.impl.PaqueteDAOImpl;
import modelo.Paquete;

import java.util.List;

public class ServicioPaquetes {

    private final PaqueteDAO paqueteDAO;

    public ServicioPaquetes() {
        this.paqueteDAO = new PaqueteDAOImpl();
    }

    // Listar todos los paquetes
    public List<Paquete> listarPaquetes() {
        return paqueteDAO.listarTodos();
    }

    // Obtener paquete por ID
    public Paquete obtenerPaquete(int id) {
        return paqueteDAO.obtenerPorId(id);
    }

    // Obtener paquete por número de guía
    public Paquete obtenerPorGuia(String guia) {
        return paqueteDAO.obtenerPorGuia(guia);
    }

    // Crear paquete
    public boolean crearPaquete(Paquete paquete) {
        return paqueteDAO.insertar(paquete);
    }

    // Actualizar paquete completo
    public boolean actualizarPaquete(Paquete paquete) {
        return paqueteDAO.actualizar(paquete);
    }

    // Actualizar solo estado
    public boolean actualizarEstado(int idPaquete, String estado) {
        return paqueteDAO.actualizarEstado(idPaquete, estado);
    }

    // Eliminar
    public boolean eliminarPaquete(int idPaquete) {
        return paqueteDAO.eliminar(idPaquete);
    }

    // Paquetes por cliente
    public List<Paquete> listarPaquetesPorCliente(int clienteId) {
        return paqueteDAO.listarPorCliente(clienteId);
    }
}

