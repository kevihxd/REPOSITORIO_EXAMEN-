package servicio;

import config.ConexionBD;
import dao.impl.UsuarioDAOImpl;
import java.sql.Connection;
import modelo.Usuario;

/**
 * Servicio para manejar autenticación de usuarios
 */
public class ServicioAutenticacion {

    private final UsuarioDAOImpl usuarioDAO;

    public ServicioAutenticacion() {
        Connection conn = ConexionBD.conectar();
        if (conn == null) {
            throw new RuntimeException("No se pudo conectar a la base de datos");
        }
        this.usuarioDAO = new UsuarioDAOImpl(conn);
    }

    /**
     * Valida un usuario y contraseña.
     * @param username Nombre de usuario
     * @param password Contraseña en texto plano
     * @return Usuario si la autenticación es correcta, null si falla
     */
    public Usuario autenticar(String username, String password) {
        Usuario usuario = usuarioDAO.buscarPorUsername(username);
        if (usuario != null && usuario.getPassword().equals(password)) {
            return usuario;
        }
        return null;
    }

}
