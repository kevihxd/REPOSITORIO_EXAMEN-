/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;


import dao.VehiculoDAO;
import dao.impl.VehiculoDAOImpl;
import modelo.Vehiculo;
import java.util.List;
/**
 *
 * @author camper
 */
public class ServicioVehiculos {
    
    private VehiculoDAO vehiculoDAO = new VehiculoDAOImpl();

    public void registrarVehiculo(Vehiculo vehiculo) {
        vehiculoDAO.insertar(vehiculo);
    }

    public List<Vehiculo> listarVehiculos() {
        return vehiculoDAO.listar();
    }

    public Vehiculo obtenerVehiculo(int id) {
        return vehiculoDAO.buscarPorId(id);
    }

    public void actualizarVehiculo(Vehiculo vehiculo) {
        vehiculoDAO.actualizar(vehiculo);
    }

    public void eliminarVehiculo(int id) {
        vehiculoDAO.eliminar(id);
    }
    
}
