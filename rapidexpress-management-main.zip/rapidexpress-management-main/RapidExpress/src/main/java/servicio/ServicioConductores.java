/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import dao.impl.ConductorDAOImpl;
import modelo.Conductor;
import modelo.enums.EstadoConductor;
import java.util.List;

public class ServicioConductores {

    private final ConductorDAOImpl dao;

    public ServicioConductores() {
        this.dao = new ConductorDAOImpl();
    }

    // Crear un nuevo conductor
    public void crearConductor(String identificacion, String nombre, String apellido,
                               String licencia, String telefono, EstadoConductor estado) {
        Conductor c = new Conductor(identificacion, nombre, apellido, licencia, telefono, estado);
        dao.insertar(c);
        System.out.println("Conductor creado correctamente.");
    }

    // Listar todos los conductores
    public List<Conductor> listarConductores() {
        return dao.listar();
    }

    // Buscar conductor por ID
    public Conductor buscarPorId(int id) {
        return dao.buscarPorId(id);
    }

    // Actualizar conductor
    public void actualizarConductor(int id, String identificacion, String nombre, String apellido,
                                    String licencia, String telefono, EstadoConductor estado) {
        Conductor c = new Conductor(id, identificacion, nombre, apellido, licencia, estado, telefono);
        dao.actualizar(c);
        System.out.println("Conductor actualizado correctamente.");
    }

    // Eliminar conductor
    public void eliminarConductor(int id) {
        dao.eliminar(id);
        System.out.println("Conductor eliminado correctamente.");
    }
}
