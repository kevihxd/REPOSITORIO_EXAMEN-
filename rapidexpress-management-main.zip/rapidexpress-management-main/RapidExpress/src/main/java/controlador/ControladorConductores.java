/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.util.List;
import java.util.Scanner;
import modelo.Conductor;
import modelo.enums.EstadoConductor;
import servicio.ServicioConductores;

public class ControladorConductores {

    private final ServicioConductores servicio;
    private final Scanner sc;

    public ControladorConductores() {
        this.servicio = new ServicioConductores();
        this.sc = new Scanner(System.in);
    }

    public void menu() {
        int opcion;
        do {
            System.out.println("\n--- MENÚ CONDUCTORES ---");
            System.out.println("1. Crear conductor");
            System.out.println("2. Listar conductores");
            System.out.println("3. Buscar conductor por ID");
            System.out.println("4. Actualizar conductor");
            System.out.println("5. Eliminar conductor");
            System.out.println("0. Salir");
            System.out.print("Seleccione opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1 -> crearConductor();
                case 2 -> listarConductores();
                case 3 -> buscarConductor();
                case 4 -> actualizarConductor();
                case 5 -> eliminarConductor();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private void crearConductor() {
        System.out.print("Identificación: ");
        String identificacion = sc.nextLine();
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Apellido: ");
        String apellido = sc.nextLine();
        System.out.print("Licencia: ");
        String licencia = sc.nextLine();
        System.out.print("Teléfono: ");
        String telefono = sc.nextLine();
        System.out.print("Estado (Activo, Vacaciones, Inactivo): ");
        EstadoConductor estado = EstadoConductor.valueOf(sc.nextLine());

        servicio.crearConductor(identificacion, nombre, apellido, licencia, telefono, estado);
    }

    private void listarConductores() {
        List<Conductor> lista = servicio.listarConductores();
        lista.forEach(c -> System.out.println(
                c.getIdConductor()+ " | " + c.getNombre() + " " + c.getApellido() + " | " + c.getEstado()
        ));
    }

    private void buscarConductor() {
        System.out.print("Ingrese ID del conductor: ");
        int id = sc.nextInt();
        Conductor c = servicio.buscarPorId(id);
        if (c != null) {
            System.out.println(c.getIdConductor()+ " | " + c.getNombre() + " " + c.getApellido() + " | " + c.getEstado());
        } else {
            System.out.println("Conductor no encontrado.");
        }
    }

    private void actualizarConductor() {
        System.out.print("Ingrese ID del conductor a actualizar: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Nueva Identificación: ");
        String identificacion = sc.nextLine();
        System.out.print("Nuevo Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Nuevo Apellido: ");
        String apellido = sc.nextLine();
        System.out.print("Nueva Licencia: ");
        String licencia = sc.nextLine();
        System.out.print("Nuevo Teléfono: ");
        String telefono = sc.nextLine();
        System.out.print("Nuevo Estado (Activo, Vacaciones, Inactivo): ");
        EstadoConductor estado = EstadoConductor.valueOf(sc.nextLine());

        servicio.actualizarConductor(id, identificacion, nombre, apellido, licencia, telefono, estado);
    }

    private void eliminarConductor() {
        System.out.print("Ingrese ID del conductor a eliminar: ");
        int id = sc.nextInt();
        servicio.eliminarConductor(id);
    }
}
