/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;


import modelo.Vehiculo;
import modelo.enums.EstadoVehiculo;
import servicio.ServicioVehiculos;

import java.util.List;
/**
 *
 * @author camper
 */
public class ControladorVehiculos {
    private ServicioVehiculos servicio = new ServicioVehiculos();

    public void crearVehiculo(String placa, String marca, String modelo,
                              int anio, int capacidad, EstadoVehiculo estado) {

        Vehiculo v = new Vehiculo(placa, marca, modelo, anio, capacidad, estado);
        servicio.registrarVehiculo(v);
    }

    public List<Vehiculo> obtenerVehiculos() {
        return servicio.listarVehiculos();
    }

    public Vehiculo obtenerVehiculoPorId(int id) {
        return servicio.obtenerVehiculo(id);
    }

    public void actualizarVehiculo(Vehiculo vehiculo) {
        servicio.actualizarVehiculo(vehiculo);
    }

    public void borrarVehiculo(int id) {
        servicio.eliminarVehiculo(id);
    }
}
