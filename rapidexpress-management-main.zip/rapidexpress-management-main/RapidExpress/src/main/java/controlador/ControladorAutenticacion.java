package controlador;

import java.util.Scanner;
import modelo.Usuario;
import servicio.ServicioAutenticacion;


public class ControladorAutenticacion {

    private final ServicioAutenticacion servicio;

    public ControladorAutenticacion() {
        this.servicio = new ServicioAutenticacion();
    }

    // Método para iniciar sesión desde consola
    public void login() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Usuario: ");
        String username = scanner.nextLine();

        System.out.print("Contraseña: ");
        String password = scanner.nextLine();

        Usuario usuario = servicio.autenticar(username, password);
        if (usuario != null) {
            System.out.println("¡Bienvenido " + usuario.getNombre() + "!");
        } else {
            System.out.println("Usuario o contraseña incorrectos.");
        }
    }

}
