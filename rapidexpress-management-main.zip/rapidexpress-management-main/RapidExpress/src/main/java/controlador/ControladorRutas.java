/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.util.List;
import java.util.Scanner;
import modelo.Ruta;
import servicio.ServicioRutas;

public class ControladorRutas {

    private final ServicioRutas servicio;
    private final Scanner scanner;

    public ControladorRutas() {
        this.servicio = new ServicioRutas();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcion = -1;
        while (opcion != 0) {
            System.out.println("\n--- MENÚ RUTAS ---");
            System.out.println("1. Crear ruta");
            System.out.println("2. Listar rutas");
            System.out.println("3. Buscar ruta por ID");
            System.out.println("4. Finalizar ruta");
            System.out.println("5. Eliminar ruta");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1 -> crearRuta();
                case 2 -> listarRutas();
                case 3 -> buscarRuta();
                case 4 -> finalizarRuta();
                case 5 -> eliminarRuta();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción inválida");
            }
        }
    }

    private void crearRuta() {
        System.out.print("ID Vehículo: ");
        int vehiculoId = Integer.parseInt(scanner.nextLine());
        System.out.print("ID Conductor: ");
        int conductorId = Integer.parseInt(scanner.nextLine());
        servicio.crearRuta(vehiculoId, conductorId);
        System.out.println("Ruta creada correctamente");
    }

    private void listarRutas() {
        List<Ruta> rutas = servicio.listarRutas();
        rutas.forEach(r -> System.out.println(
            "ID: " + r.getId() +
            ", Vehículo: " + r.getVehiculoId() +
            ", Conductor: " + r.getConductorId() +
            ", Estado: " + r.getEstado() +
            ", Inicio: " + r.getFechaInicio() +
            ", Fin: " + r.getFechaFin()
        ));
    }

    private void buscarRuta() {
        System.out.print("ID Ruta: ");
        int id = Integer.parseInt(scanner.nextLine());
        Ruta ruta = servicio.obtenerRutaPorId(id);
        if (ruta != null) {
            System.out.println("Ruta encontrada: " + ruta.getId() + " Estado: " + ruta.getEstado());
        } else {
            System.out.println("Ruta no encontrada");
        }
    }

    private void finalizarRuta() {
        System.out.print("ID Ruta a finalizar: ");
        int id = Integer.parseInt(scanner.nextLine());
        servicio.finalizarRuta(id);
        System.out.println("Ruta finalizada correctamente");
    }

    private void eliminarRuta() {
        System.out.print("ID Ruta a eliminar: ");
        int id = Integer.parseInt(scanner.nextLine());
        servicio.eliminarRuta(id);
        System.out.println("Ruta eliminada correctamente");
    }
}
