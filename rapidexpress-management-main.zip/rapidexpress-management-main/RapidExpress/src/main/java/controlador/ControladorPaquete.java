/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.PaqueteDAO;
import dao.impl.PaqueteDAOImpl;
import modelo.Paquete;
import modelo.enums.EstadoPaquete;

import java.util.List;

public class ControladorPaquete {

    private final PaqueteDAO paqueteDAO;

    public ControladorPaquete() {
        this.paqueteDAO = new PaqueteDAOImpl();
    }

    public boolean insertarPaquete(Paquete paquete) {
        return paqueteDAO.insertar(paquete);
    }

    public boolean actualizarPaquete(Paquete paquete) {
        return paqueteDAO.actualizar(paquete);
    }

    public boolean actualizarEstado(int idPaquete, EstadoPaquete nuevoEstado) {
        return paqueteDAO.actualizarEstado(idPaquete, nuevoEstado.name());
    }

    public boolean eliminarPaquete(int idPaquete) {
        return paqueteDAO.eliminar(idPaquete);
    }

    
    public Paquete obtenerPorId(int idPaquete) {
        return paqueteDAO.obtenerPorId(idPaquete);
    }

    public Paquete obtenerPorGuia(String numeroGuia) {
        return paqueteDAO.obtenerPorGuia(numeroGuia);
    }

    public List<Paquete> listarPaquetes() {
        return paqueteDAO.listarTodos();
    }
}

