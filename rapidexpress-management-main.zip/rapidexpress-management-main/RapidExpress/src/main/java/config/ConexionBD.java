package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author campus
 */
public class ConexionBD {
    private static final String URL = "jdbc:mysql://localhost:3306/rapidexpress";
    private static final String USER = "root";
    private static final String PASS = "Deibys2006$";
    
    
    public static Connection conectar(){
        try {
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException e) {
            System.out.println("ConexionBD - [ERROR] Error al conectar con la base de datos "+e.getMessage());       
        }
        return null;
    }
}