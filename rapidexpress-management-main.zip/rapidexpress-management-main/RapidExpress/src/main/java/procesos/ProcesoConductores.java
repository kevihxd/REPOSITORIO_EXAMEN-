package procesos;

import config.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import modelo.Conductor;
import modelo.enums.EstadoConductor;

public class ProcesoConductores {
    private ArrayList<Conductor> conductores = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public ProcesoConductores() {
        cargarConductoresDesdeBD();
    }

    // ================== 1. CARGAR DESDE LA BD ==================
    private void cargarConductoresDesdeBD() {
        conductores.clear();
        String sql = "SELECT id_conductor, identificacion, nombre, apellido, tipo_licencia, telefono, estado_conductor FROM conductores";
        try (Connection con = ConexionBD.conectar()) {
            if (con == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    Conductor c = new Conductor();
                    c.setIdConductor(rs.getInt("id_conductor"));
                    c.setIdentificacion(rs.getString("identificacion"));
                    c.setNombre(rs.getString("nombre"));
                    c.setApellido(rs.getString("apellido"));
                    c.setTipoLicencia(rs.getString("tipo_licencia"));
                    c.setTelefono(rs.getString("telefono"));
                    try {
                        c.setEstado(EstadoConductor.valueOf(rs.getString("estado_conductor")));
                    } catch(Exception e) {
                        c.setEstado(null);
                    }
                    conductores.add(c);
                }
            }
        } catch (Exception e) {
            System.out.println("Error cargando conductores: " + e.getMessage());
        }
    }

    // ================== 2. LISTAR ==================
    public void listarConductores() {
        cargarConductoresDesdeBD();
        System.out.println("\n--- LISTA DE CONDUCTORES ---");
        if (conductores.isEmpty()) {
            System.out.println("No hay conductores registrados.");
            return;
        }
        System.out.println("ID | Identificación | Nombre      | Apellido    | Teléfono   | Licencia      | Estado");
        for (Conductor c : conductores) {
            System.out.printf("%2d | %-14s | %-10s | %-11s | %-10s | %-12s | %s\n",
                    c.getIdConductor(), c.getIdentificacion(), c.getNombre(), c.getApellido(),
                    c.getTelefono(), c.getTipoLicencia(),
                    c.getEstado() != null ? c.getEstado().name() : "(Sin estado)");
        }
    }

    // ================== 3. BUSCAR POR ID ==================
    public void buscarConductor() {
        int id = leerEntero("Ingrese ID del conductor: ");
        cargarConductoresDesdeBD();
        for (Conductor c : conductores) {
            if (c.getIdConductor() == id) {
                System.out.println("\nID: " + c.getIdConductor());
                System.out.println("Identificación: " + c.getIdentificacion());
                System.out.println("Nombre: " + c.getNombre());
                System.out.println("Apellido: " + c.getApellido());
                System.out.println("Tipo Licencia: " + c.getTipoLicencia());
                System.out.println("Teléfono: " + c.getTelefono());
                System.out.println("Estado: " + (c.getEstado() != null ? c.getEstado().name() : "Sin estado"));
                return;
            }
        }
        System.out.println("Conductor no encontrado.");
    }

    // ================== 4. ASIGNAR CONDUCTOR A RUTA ==================
    public void asignarConductorRuta() {
        int idCond = leerEntero("ID del conductor: ");
        int idRuta = leerEntero("ID de la ruta: ");
        String sql = "UPDATE rutas SET id_conductor=? WHERE id_ruta=?";
        try (Connection con = ConexionBD.conectar()) {
            if (con == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idCond);
            ps.setInt(2, idRuta);
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Conductor asignado a la ruta correctamente.");
            } else {
                System.out.println("No se pudo asignar (verifique IDs)." );
            }
            cargarConductoresDesdeBD();
        } catch (Exception e) {
            System.out.println("Error asignando conductor: " + e.getMessage());
        }
    }

    // ================== 5. CAMBIAR ESTADO ==================
    public void cambiarEstado() {
        int id = leerEntero("ID del conductor: ");
        System.out.print("Nuevo estado (Activo/Vacaciones/Inactivo): ");
        String estado = scanner.nextLine().trim();
        if (!(estado.equalsIgnoreCase("Activo") ||
                estado.equalsIgnoreCase("Vacaciones") ||
                estado.equalsIgnoreCase("Inactivo"))) {
            System.out.println("Estado no válido. Escriba Activo, Vacaciones o Inactivo.");
            return;
        }
        String sql = "UPDATE conductores SET estado_conductor=? WHERE id_conductor=?";
        try (Connection con = ConexionBD.conectar()) {
            if (con == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, capitalize(estado));
            ps.setInt(2, id);
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Estado actualizado correctamente.");
            } else {
                System.out.println("No se encontró conductor con ese ID.");
            }
            cargarConductoresDesdeBD();
        } catch (Exception e) {
            System.out.println("Error cambiando estado: " + e.getMessage());
        }
    }

    // Auxiliar para leer enteros
    private int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        }
    }

    // Auxiliar para mayúscula inicial
    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }
}

