package procesos;


import config.ConexionBD;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import modelo.Ruta;
import modelo.enums.EstadoRuta;
import java.util.Scanner;

public class ProcesoRutas {

    private final Scanner scanner = new Scanner(System.in);

    public ProcesoRutas() {
    }

    // ========================================
    // MAPEO ENUM ↔ SQL
    // ========================================
    private String enumToSql(EstadoRuta estado) {
        return switch (estado) {
            case PLANIFICADA -> "Planificada";
            case EN_CURSO -> "En Curso";
            case FINALIZADA -> "Finalizada";
            case CANCELADA -> "Cancelada";
        };
    }

    private EstadoRuta sqlToEnum(String estado) {
        return switch (estado) {
            case "Planificada" -> EstadoRuta.PLANIFICADA;
            case "En Curso" -> EstadoRuta.EN_CURSO;
            case "Finalizada" -> EstadoRuta.FINALIZADA;
            case "Cancelada" -> EstadoRuta.CANCELADA;
            default -> null;
        };
    }

    // ========================================
    // 1. CREAR RUTA
    // ========================================
    public boolean crearRuta(int idVehiculo, int idConductor) {
        String sql = "INSERT INTO rutas(id_vehiculo, id_conductor, estado_ruta, fecha_inicio) VALUES (?,?,?,NOW())";
        try (Connection conn = ConexionBD.conectar()) {
            if (conn == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return false;
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idVehiculo);
            ps.setInt(2, idConductor);
            ps.setString(3, enumToSql(EstadoRuta.PLANIFICADA));
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("ERROR crear ruta: " + e.getMessage());
            return false;
        }
    }

    // ========================================
    // 2. LISTAR RUTAS
    // ========================================
    public ArrayList<Ruta> listarRutas() {
        ArrayList<Ruta> lista = new ArrayList<>();
        String sql = "SELECT * FROM rutas";
        try (Connection conn = ConexionBD.conectar()) {
            if (conn == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return lista;
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                LocalDateTime fechaInicio =
                        rs.getTimestamp("fecha_inicio").toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

                Timestamp fFin = rs.getTimestamp("fecha_fin");

                LocalDateTime fechaFin = (fFin != null)
                        ? fFin.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
                        : null;

                Ruta r = new Ruta(
                        rs.getInt("id_ruta"),
                        rs.getInt("id_vehiculo"),
                        rs.getInt("id_conductor"),
                        sqlToEnum(rs.getString("estado_ruta")),
                        fechaInicio,
                        fechaFin
                );

                lista.add(r);
            }
        } catch (SQLException e) {
            System.out.println("ERROR listar rutas: " + e.getMessage());
        }
        return lista;
    }

    // ========================================
    // 3. BUSCAR RUTA POR ID
    // ========================================
    public Ruta buscarRuta(int idRuta) {
        String sql = "SELECT * FROM rutas WHERE id_ruta = ?";
        try (Connection conn = ConexionBD.conectar()) {
            if (conn == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return null;
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idRuta);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                LocalDateTime fechaInicio =
                        rs.getTimestamp("fecha_inicio").toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

                Timestamp fFin = rs.getTimestamp("fecha_fin");

                LocalDateTime fechaFin = (fFin != null)
                        ? fFin.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
                        : null;

                return new Ruta(
                        rs.getInt("id_ruta"),
                        rs.getInt("id_vehiculo"),
                        rs.getInt("id_conductor"),
                        sqlToEnum(rs.getString("estado_ruta")),
                        fechaInicio,
                        fechaFin
                );
            }
        } catch (SQLException e) {
            System.out.println("ERROR buscar ruta: " + e.getMessage());
        }
        return null;
    }

    // ========================================
    // 4. CAMBIAR ESTADO
    // ========================================
    public boolean cambiarEstado(int idRuta, EstadoRuta nuevoEstado) {
        String sql;
        if (nuevoEstado == EstadoRuta.FINALIZADA) {
            sql = "UPDATE rutas SET estado_ruta = ?, fecha_fin = NOW() WHERE id_ruta = ?";
        } else {
            sql = "UPDATE rutas SET estado_ruta = ? WHERE id_ruta = ?";
        }
        try (Connection conn = ConexionBD.conectar()) {
            if (conn == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return false;
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, enumToSql(nuevoEstado));
            ps.setInt(2, idRuta);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("ERROR cambiar estado: " + e.getMessage());
            return false;
        }
    }

    // ========================================
    // 5. ASIGNAR PAQUETE A RUTA
    // ========================================
    public boolean asignarPaquete(int idRuta, int idPaquete) {
        String sql = "INSERT INTO detalle_ruta(id_ruta, id_paquete) VALUES (?,?)";
        try (Connection conn = ConexionBD.conectar()) {
            if (conn == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return false;
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idRuta);
            ps.setInt(2, idPaquete);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("ERROR asignar paquete: " + e.getMessage());
            return false;
        }
    }

    // MÉTODO INTERACTIVO PARA CREAR RUTA:
    public void crearRuta() {
        System.out.print("ID Vehículo: ");
        int idVeh = leerEntero();
        System.out.print("ID Conductor: ");
        int idCond = leerEntero();
        if (crearRuta(idVeh, idCond)) {
            System.out.println("Ruta creada correctamente.");
        } else {
            System.out.println("No se pudo crear la ruta (verifique IDs y disponibilidad). ");
        }
    }

    public void listarRutasInteractivo() {
        var rutas = listarRutas();
        if (rutas.isEmpty()) {
            System.out.println("No hay rutas registradas.");
            return;
        }
        System.out.println("--- LISTA DE RUTAS ---");
        for (var r : rutas) {
            System.out.printf("ID: %d | Vehiculo: %d | Conductor: %d | Estado: %s | Fecha inicio: %s | Fecha fin: %s\n", 
                r.getId(), r.getVehiculoId(), r.getConductorId(), r.getEstado(), r.getFechaInicio(), r.getFechaFin());
        }
    }

    public void buscarRutaInteractivo() {
        System.out.print("ID de la ruta: ");
        int id = leerEntero();
        Ruta r = buscarRuta(id);
        if (r == null) {
            System.out.println("No se encontró la ruta.");
        } else {
            System.out.printf("ID: %d | Vehiculo: %d | Conductor: %d | Estado: %s | Fecha inicio: %s | Fecha fin: %s\n", 
                r.getId(), r.getVehiculoId(), r.getConductorId(), r.getEstado(), r.getFechaInicio(), r.getFechaFin());
        }
    }

    public void asignarConductor() {
        System.out.print("ID de la ruta: ");
        int idRuta = leerEntero();
        System.out.print("ID nuevo conductor: ");
        int idCond = leerEntero();
        String sql = "UPDATE rutas SET id_conductor = ? WHERE id_ruta = ?";
        try (Connection conn = ConexionBD.conectar()) {
            if (conn == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idCond);
            ps.setInt(2, idRuta);
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Conductor asignado correctamente a la ruta.");
            } else {
                System.out.println("No se pudo asignar (verifique IDs)." );
            }
        } catch (SQLException e) {
            System.out.println("Error asignando conductor: " + e.getMessage());
        }
    }

    public void asignarVehiculo() {
        System.out.print("ID de la ruta: ");
        int idRuta = leerEntero();
        System.out.print("ID nuevo vehiculo: ");
        int idVeh = leerEntero();
        String sql = "UPDATE rutas SET id_vehiculo = ? WHERE id_ruta = ?";
        try (Connection conn = ConexionBD.conectar()) {
            if (conn == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idVeh);
            ps.setInt(2, idRuta);
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Vehículo asignado correctamente a la ruta.");
            } else {
                System.out.println("No se pudo asignar (verifique IDs)." );
            }
        } catch (SQLException e) {
            System.out.println("Error asignando vehículo: " + e.getMessage());
        }
    }

    public void agregarPaquetes() {
        System.out.print("ID de la ruta: ");
        int idRuta = leerEntero();
        while (true) {
            System.out.print("ID paquete a agregar (o -1 para terminar): ");
            int idPaquete = leerEntero();
            if (idPaquete == -1) break;
            if (asignarPaquete(idRuta, idPaquete)) {
                System.out.println("Paquete asignado correctamente.");
            } else {
                System.out.println("No se pudo asignar el paquete (verifique IDs)." );
            }
        }
    }

    public void cambiarEstadoRuta() {
        System.out.print("ID de la ruta: ");
        int idRuta = leerEntero();
        System.out.println("Nuevo estado (PLANIFICADA, EN_CURSO, FINALIZADA, CANCELADA): ");
        String estadoStr = scanner.nextLine();
        EstadoRuta nuevoEstado;
        try {
            nuevoEstado = EstadoRuta.valueOf(estadoStr.toUpperCase());
        } catch (Exception e) {
            System.out.println("Estado no válido.");
            return;
        }
        if (cambiarEstado(idRuta, nuevoEstado)) {
            System.out.println("Estado de la ruta actualizado.");
        } else {
            System.out.println("No se pudo actualizar el estado (verifique ID)." );
        }
    }

    public void cerrarRuta() {
        System.out.print("ID de la ruta a cerrar: ");
        int idRuta = leerEntero();
        if (cambiarEstado(idRuta, EstadoRuta.FINALIZADA)) {
            System.out.println("Ruta cerrada correctamente.");
        } else {
            System.out.println("No se pudo cerrar la ruta (verifique ID).");
        }
    }

    // Validación seguro para enteros
    private int leerEntero() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número válido.");
            }
        }
    }
}