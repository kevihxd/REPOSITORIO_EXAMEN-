/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package procesos;

import java.util.List;
import java.util.Scanner;
import modelo.Conductor;
import modelo.DetalleRuta;
import modelo.Paquete;
import modelo.Ruta;
import modelo.Vehiculo;
import servicio.ServicioConductores;
import servicio.ServicioPaquetes;
import servicio.ServicioRutas;
import servicio.ServicioVehiculos;

/**
 *
 * @author camper
 */
public class ProcesoMenuAuditoria {
     private final ServicioPaquetes servicioPaquetes = new ServicioPaquetes();
    private final ServicioVehiculos servicioVehiculos = new ServicioVehiculos();
    private final ServicioConductores servicioConductores = new ServicioConductores();
    private final ServicioRutas servicioRutas = new ServicioRutas();
    Scanner sc = new Scanner(System.in);
    public void verPaquetes() {
        System.out.println("\n=== Listado de Paquetes ===");
        List<Paquete> lista = servicioPaquetes.listarPaquetes();
        lista.forEach(p -> System.out.println(p.getNumero_Guia() + " - " + p.getDescripcion() + " - Estado: " + p.getEstado_paquete()));
    }

    public void verVehiculos() {
         System.out.println("\n=== Listado de Vehículos ===");
        List<Vehiculo> lista = servicioVehiculos.listarVehiculos();
        lista.forEach(v -> System.out.println(v.getMarca() + " - " + v.getPlaca()));
    }

    public void verConductores() {
       System.out.println("\n=== Listado de Conductores ===");
        List<Conductor> lista = servicioConductores.listarConductores();
        lista.forEach(c -> System.out.println(c.getNombre() + " " + c.getApellido()));
    }

    public void verRutas() {
        System.out.println("\n=== Listado de Rutas ===");
        List<Ruta> lista = servicioRutas.listarRutas();
        lista.forEach(r -> System.out.println("Ruta " + r.getId() + " - Estado: " + r.getEstado()));
    
    }

    public void verDetalleRuta() {
       System.out.println("\n--- DETALLE DE RUTA ---");
       System.out.println("ingres el id de la ruta ej; 1");
      servicioRutas.obtenerRutaPorId(sc.nextInt());

        
    
    }
}
