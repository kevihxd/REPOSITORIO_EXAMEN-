/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package procesos;

import config.ConexionBD;
import modelo.Usuario;
import modelo.Conductor;
import modelo.Vehiculo;
import modelo.Paquete;
import modelo.Ruta;

import servicio.ServicioUsuarios;
import servicio.ServicioConductores;
import servicio.ServicioVehiculos;
import servicio.ServicioPaquetes;
import servicio.ServicioRutas;

import dao.impl.UsuarioDAOImpl;
import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

/**
 *
 * @author camper
 */
public class ProcesosMenuAdmin {
    private Scanner scanner = new Scanner(System.in);

    private UsuarioDAOImpl importUsuarios = new UsuarioDAOImpl(ConexionBD.conectar());
    private ServicioUsuarios servicioUsuarios = new ServicioUsuarios();
    private ServicioConductores servicioConductores = new ServicioConductores();
    private ServicioVehiculos servicioVehiculos = new ServicioVehiculos();
    private ServicioPaquetes servicioPaquetes = new ServicioPaquetes();
    private ServicioRutas servicioRutas = new ServicioRutas();

    // ==================== MÉTODOS REALES ====================

    public void gestionarUsuarios() {
        System.out.println("\n=== Listado de Usuarios ===");
        List<Usuario> usuarios = servicioUsuarios.listarUsuarios();
        usuarios.forEach(u -> System.out.println(u.getNombre() + " (" + u.getUsername() + ") - Rol ID: " + u.getRolId()));

        System.out.println("¿Desea crear un nuevo usuario? (s/n)");
        String resp = scanner.nextLine();
        if (resp.equalsIgnoreCase("s")) {
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();

            System.out.print("Username: ");
            String username = scanner.nextLine();

            System.out.print("Password: ");
            String password = scanner.nextLine();

            System.out.print("Rol ID: ");
            int rolId = Integer.parseInt(scanner.nextLine());

            List<Usuario> lista = new ArrayList<>();

            Usuario user = new Usuario();
            user.setNombre(nombre);
            user.setUsername(username);
            user.setPassword(password);
            user.setRolId(rolId);

            lista.add(user);

            importUsuarios.insertar(user);

            
            System.out.println("Usuario creado con éxito.");
            
        }
    }

    public void gestionarConductores() {
        System.out.println("\n=== Listado de Conductores ===");
        List<Conductor> lista = servicioConductores.listarConductores();
        lista.forEach(c -> System.out.println(c.getNombre() + " " + c.getApellido()));
    }

    public void gestionarVehiculos() {
        System.out.println("\n=== Listado de Vehículos ===");
        List<Vehiculo> lista = servicioVehiculos.listarVehiculos();
        lista.forEach(v -> System.out.println(v.getMarca() + " - " + v.getPlaca()));
    }

    public void gestionarPaquetes() {
        System.out.println("\n=== Listado de Paquetes ===");
        List<Paquete> lista = servicioPaquetes.listarPaquetes();
        lista.forEach(p -> System.out.println(p.getNumero_Guia() + " - " + p.getDescripcion() + " - Estado: " + p.getEstado_paquete()));
    }

    public void gestionarRutas() {
        System.out.println("\n=== Listado de Rutas ===");
        List<Ruta> lista = servicioRutas.listarRutas();
        lista.forEach(r -> System.out.println("Ruta " + r.getId() + " - Estado: " + r.getEstado()));
    }
}
