package procesos;


import config.ConexionBD;
import modelo.Vehiculo;
import modelo.enums.EstadoVehiculo;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class ProcesoVehiculos {

    private ArrayList<Vehiculo> vehiculos = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public ProcesoVehiculos() {
        cargarVehiculosDesdeBD();
    }

    // ============================================================
    // Cargar vehículos desde la BD hacia el ArrayList
    // ============================================================
    private void cargarVehiculosDesdeBD() {
        vehiculos.clear();

        String sql = "SELECT * FROM vehiculos";

        try (Connection con = ConexionBD.conectar()) {
            if (con == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    EstadoVehiculo estado;
                    try {
                        String estadoDb = rs.getString("estado_vehiculo");
                        if (estadoDb != null) {
                            // Mapear desde BD: "En Ruta" -> "En_Ruta", "En Mantenimiento" -> "En_Mantenimiento"
                            estado = EstadoVehiculo.valueOf(estadoDb.trim().replace(" ", "_"));
                        } else {
                            estado = null;
                        }
                    } catch (Exception e) { estado = null; }
                    Vehiculo v = new Vehiculo(
                            rs.getInt("id_vehiculo"),
                            rs.getString("placa"),
                            rs.getString("marca"),
                            rs.getString("modelo"),
                            rs.getInt("anio_fabricacion"),
                            rs.getInt("capacidad_kg"),
                            estado,
                            rs.getString("created_at")
                    );
                    vehiculos.add(v);
                }
            }
        } catch (Exception e) {
            System.out.println("Error cargando vehículos: " + e.getMessage());
        }
    }

    // ============================================================
    // 1. LISTAR
    // ============================================================
    public void listarVehiculos() {
        cargarVehiculosDesdeBD();
        System.out.println("\n--- LISTA DE VEHÍCULOS ---");
        if (vehiculos.isEmpty()) {
            System.out.println("No hay vehículos registrados.");
            return;
        }
        System.out.println("ID | Placa   | Marca     | Modelo    | Año | Capacidad | Estado      | Creado");
        for (Vehiculo v : vehiculos) {
            System.out.printf("%d | %-7s | %-9s | %-9s | %d | %d Kg    | %-15s | %s\n",
                v.getIdVehiculo(), v.getPlaca(), v.getMarca(), v.getModelo(),
                v.getAnioFabricacion(), v.getCapacidadKg(),
                v.getEstadoVehiculo() != null ? v.getEstadoVehiculo().name() : "(Sin estado)",
                v.getCreatedAt());
        }
    }

    // ============================================================
    // 2. BUSCAR POR PLACA
    // ============================================================
    public void buscarVehiculo() {
        cargarVehiculosDesdeBD();
        System.out.print("Ingrese la placa: ");
        String placa = scanner.nextLine();

        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                mostrarVehiculo(v);
                return;
            }
        }

        System.out.println("Vehículo no encontrado.");
    }

    private void mostrarVehiculo(Vehiculo v) {
        System.out.println("\n--- Información del Vehículo ---");
        System.out.println("ID: " + v.getIdVehiculo());
        System.out.println("Placa: " + v.getPlaca());
        System.out.println("Marca: " + v.getMarca());
        System.out.println("Modelo: " + v.getModelo());
        System.out.println("Año Fabricación: " + v.getAnioFabricacion());
        System.out.println("Capacidad Kg: " + v.getCapacidadKg());
        System.out.println("Estado: " + (v.getEstadoVehiculo() != null ? v.getEstadoVehiculo().name() : "Sin estado"));
        System.out.println("Creado en: " + v.getCreatedAt());
    }

    // ============================================================
    // 3. VER ESTADO DEL VEHÍCULO
    // ============================================================
    public void verEstadoVehiculo() {
        cargarVehiculosDesdeBD();
        System.out.print("Ingrese la placa: ");
        String placa = scanner.nextLine();

        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                System.out.println("Estado del vehículo: " + (v.getEstadoVehiculo() != null ? v.getEstadoVehiculo().name() : "Sin estado"));
                return;
            }
        }

        System.out.println("Vehículo no encontrado.");
    }
}