/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package procesos;

import java.util.Scanner;
import servicio.ServicioPaquetes;
import modelo.DatosPersona;
import modelo.Paquete;
import modelo.Usuario;

public class ProcesosMenuCliente {

    private final Scanner scanner = new Scanner(System.in);
    private final ServicioPaquetes servicioPaquetes = new ServicioPaquetes();

    public void verMisPaquetes(Usuario usuario) {
        System.out.println("\n--- MIS PAQUETES ---");
        servicioPaquetes.listarPaquetesPorCliente(usuario.getIdUsuario())
                .forEach(System.out::println);
    }

    public void consultarEstado(Usuario usuario) {
        System.out.print("Ingrese ID del paquete: ");
        int idPaquete = scanner.nextInt();
        scanner.nextLine();

        Paquete paquete = servicioPaquetes.obtenerPaquete(idPaquete);

        if (paquete == null) {
            System.out.println("No existe el paquete.");
            return;
        }

        // Validar propietario
        DatosPersona rem = paquete.getRemitente_id();
        DatosPersona dest = paquete.getDestinatario_id();
        int uid = usuario.getIdUsuario();

        boolean pertenece = (rem != null && rem.getId_persona() == uid)
                || (dest != null && dest.getId_persona() == uid);

        if (!pertenece) {
            System.out.println("No tienes permiso para ver este paquete.");
            return;
        }

        System.out.println("Estado actual: " + paquete.getEstado_paquete());
    }

    public void verDetallePaquete(Usuario usuario) {
        System.out.print("Ingrese ID del paquete: ");
        int idPaquete = scanner.nextInt();
        scanner.nextLine();

        Paquete paquete = servicioPaquetes.obtenerPaquete(idPaquete);

        if (paquete == null) {
            System.out.println("No existe el paquete.");
            return;
        }

        int userId = usuario.getIdUsuario();

        boolean pertenece
                = (paquete.getDestinatario_id() != null && paquete.getDestinatario_id().getId_persona() == userId)
                || (paquete.getRemitente_id() != null && paquete.getRemitente_id().getId_persona() == userId);

        if (!pertenece) {
            System.out.println("No existe el paquete o no te pertenece.");
            return;
        }

        System.out.println("\n--- DETALLES DEL PAQUETE ---");
        System.out.println(paquete);
    }


    public void solicitarEnvio(Usuario usuario) {

        System.out.println("\n=== SOLICITAR ENVÍO DE PAQUETE ===");

        Paquete paquete = new Paquete();

        // Remitente 
        DatosPersona remitente = new DatosPersona();
        remitente.setId_persona(usuario.getIdUsuario());
        paquete.setRemitente_id(remitente);

        // Destinatario
        System.out.print("Ingrese ID del destinatario: ");
        int idDest = scanner.nextInt();
        scanner.nextLine();

        DatosPersona destinatario = new DatosPersona();
        destinatario.setId_persona(idDest);
        paquete.setDestinatario_id(destinatario);

        // Datos del paquete
        System.out.print("Descripción del paquete: ");
        paquete.setDescripcion(scanner.nextLine());

        System.out.print("Peso (kg): ");
        paquete.setPeso(scanner.nextDouble());

        System.out.print("Dimensiones (cm): ");
        paquete.setDimensiones(scanner.nextLine());
        scanner.nextLine();
        
         System.out.println("Numero de guia");
        paquete.setNumero_Guia(scanner.nextLine());

        // Dirección
        System.out.print("Ciudad destino: ");
        String ciudad = scanner.nextLine();

        System.out.print("Dirección exacta: ");
        String direccion = scanner.nextLine();
         
  
        paquete.setDireccion_destino(ciudad + " - " + direccion);

        // Estado inicial
        paquete.setEstado_paquete("En Bodega");
        

        // Guardar paquete
        boolean creado = servicioPaquetes.crearPaquete(paquete);

        if (creado) {
            System.out.println("\n Paquete solicitado exitosamente.");

        } else {
            System.out.println(" Error al registrar el paquete.");
        }
    }

}

