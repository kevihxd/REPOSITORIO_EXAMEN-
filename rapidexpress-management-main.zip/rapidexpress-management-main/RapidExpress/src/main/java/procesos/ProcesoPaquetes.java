package procesos;


import config.ConexionBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;
import modelo.Paquete;
import modelo.DatosPersona;
import modelo.enums.EstadoPaquete;

public class ProcesoPaquetes {

    private ArrayList<Paquete> paquetes = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public ProcesoPaquetes() {
        cargarPaquetesDesdeBD();
    }

    // ============================================================
    // CARGAR PAQUETES
    // ============================================================
    private void cargarPaquetesDesdeBD() {

        paquetes.clear();
        String sql = "SELECT * FROM paquetes";

        try (Connection con = ConexionBD.conectar()) {
            if (con == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            try (Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    DatosPersona remitente = new DatosPersona();
                    remitente.setId_persona(rs.getInt("remitente_id"));

                    DatosPersona destinatario = new DatosPersona();
                    destinatario.setId_persona(rs.getInt("destinatario_id"));

                    Paquete p = new Paquete(
                            rs.getInt("id_paquete"),
                            rs.getString("Numero_Guia"),
                            rs.getString("descripcion"),
                            rs.getDouble("peso"),
                            rs.getString("dimensiones"),
                            remitente,
                            destinatario,
                            rs.getString("direccion_origen"),
                            rs.getString("direccion_destino"),
                            rs.getString("estado_paquete"),
                            rs.getString("created_at")
                    );
                    paquetes.add(p);
                }
            }
        } catch (Exception e) {
            System.out.println("Error cargando paquetes: " + e.getMessage());
        }
    }

    // ============================================================
    // REGISTRAR PAQUETE
    // ============================================================
    public void registrarPaquete() {

        System.out.println("\n--- REGISTRO DE PAQUETE ---");

        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();

        System.out.print("Peso (Kg): ");
        double peso = leerDouble();

        System.out.print("Dimensiones (cm): ");
        String dimensiones = scanner.nextLine();

        System.out.print("ID remitente: ");
        int remitente = leerEntero();

        System.out.print("ID destinatario: ");
        int destinatario = leerEntero();

        System.out.print("Dirección de origen: ");
        String dirOrigen = scanner.nextLine();

        System.out.print("Dirección de destino: ");
        String dirDestino = scanner.nextLine();

        // Generar un número de guía simple
        String numeroGuia = "G" + (int)(Math.random() * 900000 + 100000);

        String sql = """
            INSERT INTO paquetes 
            (Numero_Guia, descripcion, peso, dimensiones, remitente_id, destinatario_id,
             direccion_origen, direccion_destino, estado_paquete)
            VALUES (?,?,?,?,?,?,?,?,?)
        """;

        try (Connection con = ConexionBD.conectar()) {
            if (con == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, numeroGuia);
            ps.setString(2, descripcion);
            ps.setDouble(3, peso);
            ps.setString(4, dimensiones);
            ps.setInt(5, remitente);
            ps.setInt(6, destinatario);
            ps.setString(7, dirOrigen);
            ps.setString(8, dirDestino);
            // Mapear enum a valor de BD: En_Bodega -> "En Bodega"
            ps.setString(9, "En Bodega");

            ps.executeUpdate();

            System.out.println("Paquete registrado con guía: " + numeroGuia);

            cargarPaquetesDesdeBD();

        } catch (Exception e) {
            System.out.println("Error registrando paquete: " + e.getMessage());
        }
    }

    // ============================================================
    // LISTAR PAQUETES
    // ============================================================
    public void listarPaquetes() {
        cargarPaquetesDesdeBD();
        System.out.println("\n--- LISTA DE PAQUETES ---");
        if (paquetes.isEmpty()) {
            System.out.println("No hay paquetes registrados.");
            return;
        }
        System.out.println("ID | Guía    | Desc       | Estado");
        for (Paquete p : paquetes) {
            System.out.printf("%d | %-8s | %-10s | %s\n",
                    p.getId_paquete(), p.getNumero_Guia(), p.getDescripcion(), p.getEstado_paquete());
        }
    }

    // ============================================================
    // BUSCAR PAQUETE
    // ============================================================
    public void buscarPaquete() {
        cargarPaquetesDesdeBD();
        System.out.print("Ingrese el ID del paquete: ");
        int id = leerEntero();

        for (Paquete p : paquetes) {
            if (p.getId_paquete() == id) {
                mostrarPaquete(p);
                return;
            }
        }

        System.out.println("Paquete no encontrado.");
    }
    
    private int leerEntero() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        }
    }
    
    private double leerDouble() {
        while (true) {
            try {
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        }
    }

    private void mostrarPaquete(Paquete p) {
        System.out.println("\n--- DETALLE DEL PAQUETE ---");
        System.out.println("ID: " + p.getId_paquete());
        System.out.println("Guía: " + p.getNumero_Guia());
        System.out.println("Descripción: " + p.getDescripcion());
        System.out.println("Peso: " + p.getPeso());
        System.out.println("Dimensiones: " + p.getDimensiones());
        System.out.println("Remitente ID: " + p.getRemitente_id().getId_persona());
        System.out.println("Destinatario ID: " + p.getDestinatario_id().getId_persona());
        System.out.println("Origen: " + p.getDireccion_origen());
        System.out.println("Destino: " + p.getDireccion_destino());
        System.out.println("Estado: " + p.getEstado_paquete());
        System.out.println("Creado: " + p.getCreated_at());
    }

    // ============================================================
    // CAMBIAR ESTADO
    // ============================================================
    public void cambiarEstadoPaquete() {
        System.out.print("ID del paquete: ");
        int id = leerEntero();

        System.out.println("Nuevo estado disponible:");
        for (EstadoPaquete ep : EstadoPaquete.values()) {
            System.out.println("- " + ep.name());
        }

        System.out.print("Seleccione estado: ");
        String estadoStr = scanner.nextLine().trim();
        
        // Mapear desde enum a valor de BD
        String estadoBD = mapearEstadoABD(estadoStr);
        if (estadoBD == null) {
            System.out.println("Estado no válido. Use uno de los estados disponibles.");
            return;
        }

        String sql = "UPDATE paquetes SET estado_paquete=? WHERE id_paquete=?";

        try (Connection con = ConexionBD.conectar()) {
            if (con == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, estadoBD);
            ps.setInt(2, id);
            ps.executeUpdate();
            System.out.println("Estado actualizado.");
            cargarPaquetesDesdeBD();
        } catch (Exception e) {
            System.out.println("Error cambiando estado: " + e.getMessage());
        }
    }
    
    private String mapearEstadoABD(String estadoEnum) {
        try {
            EstadoPaquete estado = EstadoPaquete.valueOf(estadoEnum.toUpperCase());
            return switch (estado) {
                case En_Bodega -> "En Bodega";
                case Asignado_a_Ruta -> "Asignado a Ruta";
                case En_Transito -> "En Transito";
                case Entregado -> "Entregado";
                case Devuelto -> "Devuelto";
            };
        } catch (Exception e) {
            return null;
        }
    }

    // ============================================================
    // ASIGNAR PAQUETE A RUTA
    // ============================================================
    public void asignarPaqueteRuta() {
        System.out.print("ID del paquete: ");
        int idPaquete = leerEntero();

        System.out.print("ID de la ruta: ");
        int idRuta = leerEntero();

        String sql = "UPDATE paquetes SET id_ruta=?, estado_paquete=? WHERE id_paquete=?";

        try (Connection con = ConexionBD.conectar()) {
            if (con == null) {
                System.out.println("Error: No se pudo conectar a la base de datos.");
                return;
            }
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idRuta);
            // Mapear enum a valor de BD: Asignado_a_Ruta -> "Asignado a Ruta"
            ps.setString(2, "Asignado a Ruta");
            ps.setInt(3, idPaquete);

            ps.executeUpdate();

            System.out.println("Paquete asignado a ruta.");

            cargarPaquetesDesdeBD();

        } catch (Exception e) {
            System.out.println("Error asignando paquete a ruta: " + e.getMessage());
        }
    }
}