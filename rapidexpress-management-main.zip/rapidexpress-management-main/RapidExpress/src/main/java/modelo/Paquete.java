/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author camper
 */

public class Paquete {
    private int id_paquete;
    private String Numero_Guia;
    private String descripcion;
    private double peso;
    private String dimensiones;
    private DatosPersona remitente_id;
    private DatosPersona destinatario_id;
    private String direccion_origen;
    private String direccion_destino;
    private String estado_paquete;
    private String created_at;

    public Paquete(){}

    public Paquete(int id_paquete, String Numero_Guia, String descripcion, double peso, String dimensiones, DatosPersona remitente_id, DatosPersona destinatario_id, String direccion_origen, String direccion_destino, String estado_paquete, String created_at) {
        this.id_paquete = id_paquete;
        this.Numero_Guia = Numero_Guia;
        this.descripcion = descripcion;
        this.peso = peso;
        this.dimensiones = dimensiones;
        this.remitente_id = remitente_id;
        this.destinatario_id = destinatario_id;
        this.direccion_origen = direccion_origen;
        this.direccion_destino = direccion_destino;
        this.estado_paquete = estado_paquete;
        this.created_at = created_at;
    }

    public int getId_paquete() {
         return id_paquete; 
        }

    public void setId_paquete(int id_paquete) {
         this.id_paquete = id_paquete; 
        }

    public String getNumero_Guia() {
         return Numero_Guia; 
        }

    public void setNumero_Guia(String Numero_Guia) {
         this.Numero_Guia = Numero_Guia; 
        }

    public String getDescripcion() {
         return descripcion; 
        }

    public void setDescripcion(String descripcion) {
         this.descripcion = descripcion; 
        }

    public double getPeso() {
         return peso; 
        }

    public void setPeso(double peso) { 
         this.peso = peso; 
        }

    public String getDimensiones() {
         return dimensiones; 
        }

    public void setDimensiones(String dimensiones) {
         this.dimensiones = dimensiones;
        }

    public DatosPersona getRemitente_id() {
        return remitente_id; 
    }

    public void setRemitente_id(DatosPersona remitente_id) {
        this.remitente_id = remitente_id; 
    }

    public DatosPersona getDestinatario_id() {
        return destinatario_id; 
    }

    public void setDestinatario_id(DatosPersona destinatario_id) {
        this.destinatario_id = destinatario_id; 
    }


    public String getDireccion_origen() {
         return direccion_origen; 
        }

    public void setDireccion_origen(String direccion_origen) {
         this.direccion_origen = direccion_origen; 
        }

    public String getDireccion_destino() { 
         return direccion_destino; 
        }

    public void setDireccion_destino(String direccion_destino) { 
         this.direccion_destino = direccion_destino; 
        }

    public String getEstado_paquete() { 
         return estado_paquete; 
        }

    public void setEstado_paquete(String estado_paquete) {
         this.estado_paquete = estado_paquete; 
        }

    public String getCreated_at() {
         return created_at; 
        }

    public void setCreated_at(String created_at) {
         this.created_at = created_at; 
        }

}
