/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import modelo.enums.EstadoRuta;
import java.time.LocalDateTime;

/**
 *
 * @author camper
 */
public class Ruta {
    private int id;
    private int vehiculoId;
    private int conductorId;
    private EstadoRuta estado;
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaFin;

    public Ruta() {
    }

    public Ruta(int id, int vehiculoId, int conductorId, EstadoRuta estado, LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        this.id = id;
        this.vehiculoId = vehiculoId;
        this.conductorId = conductorId;
        this.estado = estado;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getVehiculoId() {
        return vehiculoId;
    }

    public void setVehiculoId(int vehiculoId) {
        this.vehiculoId = vehiculoId;
    }

    public int getConductorId() {
        return conductorId;
    }

    public void setConductorId(int conductorId) {
        this.conductorId = conductorId;
    }

    public EstadoRuta getEstado() {
        return estado;
    }

    public void setEstado(EstadoRuta estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDateTime fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDateTime getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDateTime fechaFin) {
        this.fechaFin = fechaFin;
    }
}
