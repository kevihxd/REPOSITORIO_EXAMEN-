/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import modelo.enums.EstadoConductor;
/**
 *
 * @author camper
 */

public class Conductor {

    private int idConductor;          
    private String identificacion;     
    private String nombre;             
    private String apellido;          
    private String tipoLicencia;       
    private String telefono;         
    private EstadoConductor estado;  

    public Conductor() {}

    public Conductor(int idConductor, String identificacion, String nombre, String apellido, String tipoLicencia, EstadoConductor estado, String telefono) {

        this.idConductor = idConductor;
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipoLicencia = tipoLicencia;
        this.telefono = telefono;
        this.estado = estado;
    }

    public Conductor(String identificacion, String nombre, String apellido, String tipoLicencia, String telefono, EstadoConductor estado) {

        this.identificacion = identificacion;
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipoLicencia = tipoLicencia;
        this.telefono = telefono;
        this.estado = estado;
    }

    public int getIdConductor() {
        return idConductor;
    }

    public void setIdConductor(int idConductor) {
        this.idConductor = idConductor;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTipoLicencia() {
        return tipoLicencia;
    }

    public void setTipoLicencia(String tipoLicencia) {
        this.tipoLicencia = tipoLicencia;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public EstadoConductor getEstado() {
        return estado;
    }

    public void setEstado(EstadoConductor estado) {
        this.estado = estado;
    }
}