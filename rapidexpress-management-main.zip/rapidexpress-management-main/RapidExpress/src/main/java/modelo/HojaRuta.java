/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author camper
 */
public class HojaRuta {
    private int id;
    private int idRuta;
    private int idVehiculo;
    private int idConductor;
    private LocalDateTime fechaCreacion;
    private List<Integer> paquetesIds; // lista de paquetes asignados

    public HojaRuta() {}

    public HojaRuta(int id, int idRuta, int idVehiculo, int idConductor, LocalDateTime fechaCreacion, List<Integer> paquetesIds) {
        this.id = id;
        this.idRuta = idRuta;
        this.idVehiculo = idVehiculo;
        this.idConductor = idConductor;
        this.fechaCreacion = fechaCreacion;
        this.paquetesIds = paquetesIds;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdRuta() { return idRuta; }
    public void setIdRuta(int idRuta) { this.idRuta = idRuta; }

    public int getIdVehiculo() { return idVehiculo; }
    public void setIdVehiculo(int idVehiculo) { this.idVehiculo = idVehiculo; }

    public int getIdConductor() { return idConductor; }
    public void setIdConductor(int idConductor) { this.idConductor = idConductor; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public List<Integer> getPaquetesIds() { return paquetesIds; }
    public void setPaquetesIds(List<Integer> paquetesIds) { this.paquetesIds = paquetesIds; }
}
