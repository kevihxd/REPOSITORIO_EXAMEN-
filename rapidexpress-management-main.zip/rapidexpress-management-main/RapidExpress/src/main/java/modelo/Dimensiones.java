/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author camper
 */
public class Dimensiones {
    private int id;
    private double largo;
    private double ancho;
    private double alto;

    public Dimensiones() {}

    public Dimensiones(int id, double largo, double ancho, double alto) {
        this.id = id;
        this.largo = largo;
        this.ancho = ancho;
        this.alto = alto;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public double getLargo() { return largo; }
    public void setLargo(double largo) { this.largo = largo; }

    public double getAncho() { return ancho; }
    public void setAncho(double ancho) { this.ancho = ancho; }

    public double getAlto() { return alto; }
    public void setAlto(double alto) { this.alto = alto; }
}
