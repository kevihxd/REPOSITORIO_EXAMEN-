/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.util.Date;
import modelo.Vehiculo;

/**
 *
 * @author camper
 */

public class Mantenimiento {
    private int id_mantenimiento;
    private Vehiculo id_vehiculo;
    private Date fecha_mantenimiento;
    private String descripcion;
    private String tipo;
    private double costo;
    private String realizado_por;

    public Mantenimiento() {}

    public Mantenimiento(int id_mantenimiento, Vehiculo id_vehiculo, Date fecha_mantenimiento,
                        String descripcion, String tipo, double costo, String realizado_por) {
        this.id_mantenimiento = id_mantenimiento;
        this.id_vehiculo = id_vehiculo;
        this.fecha_mantenimiento = fecha_mantenimiento;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.costo = costo;
        this.realizado_por = realizado_por;
    }

    public int getId_mantenimiento() {
        return id_mantenimiento;
    }

    public void setId_mantenimiento(int id_mantenimiento) {
        this.id_mantenimiento = id_mantenimiento;
    }

    public Vehiculo getId_vehiculo() {
        return id_vehiculo;
    }

    public void setId_vehiculo(Vehiculo id_vehiculo) {
        this.id_vehiculo = id_vehiculo;
    }

    public Date getFecha_mantenimiento() {
        return fecha_mantenimiento;
    }

    public void setFecha_mantenimiento(Date fecha_mantenimiento) {
        this.fecha_mantenimiento = fecha_mantenimiento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public String getRealizado_por() {
        return realizado_por;
    }

    public void setRealizado_por(String realizado_por) {
        this.realizado_por = realizado_por;
    }

}
