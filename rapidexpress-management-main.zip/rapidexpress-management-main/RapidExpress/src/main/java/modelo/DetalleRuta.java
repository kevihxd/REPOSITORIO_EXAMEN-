/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import modelo.enums.EstadoDetalleRuta;
import java.time.LocalDateTime;

/**
 *
 * @author camper
 */
public class DetalleRuta {
    private int idDetalle;
    private int idRuta;
    private int idPaquete;
    private LocalDateTime fechaAsignacion;
    private LocalDateTime fechaEntrega;
    private EstadoDetalleRuta estado;

    public DetalleRuta() {
    }

    public DetalleRuta(int idDetalle, int idRuta, int idPaquete, LocalDateTime fechaAsignacion, LocalDateTime fechaEntrega, EstadoDetalleRuta estado) {
        this.idDetalle = idDetalle;
        this.idRuta = idRuta;
        this.idPaquete = idPaquete;
        this.fechaAsignacion = fechaAsignacion;
        this.fechaEntrega = fechaEntrega;
        this.estado = estado;
    }

    public int getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.idDetalle = idDetalle;
    }

    public int getIdRuta() {
        return idRuta;
    }

    public void setIdRuta(int idRuta) {
        this.idRuta = idRuta;
    }

    public int getIdPaquete() {
        return idPaquete;
    }

    public void setIdPaquete(int idPaquete) {
        this.idPaquete = idPaquete;
    }

    public LocalDateTime getFechaAsignacion() {
        return fechaAsignacion;
    }

    public void setFechaAsignacion(LocalDateTime fechaAsignacion) {
        this.fechaAsignacion = fechaAsignacion;
    }

    public LocalDateTime getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(LocalDateTime fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public EstadoDetalleRuta getEstado() {
        return estado;
    }

    public void setEstado(EstadoDetalleRuta estado) {
        this.estado = estado;
    }
}
