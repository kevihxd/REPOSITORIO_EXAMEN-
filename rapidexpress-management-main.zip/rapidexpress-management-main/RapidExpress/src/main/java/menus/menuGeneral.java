/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menus;

import modelo.Usuario;
import servicio.ServicioAutenticacion;
import java.util.Scanner;

/**
 *
 * @author camper
 */
public class menuGeneral {

    private Scanner scanner = new Scanner(System.in);
    private ServicioAutenticacion authService = new ServicioAutenticacion();

    private MenuAdmin menuAdmin = new MenuAdmin();
    private MenuOperador menuOperador = new MenuOperador();
    private MenuAuditor menuAuditor = new MenuAuditor();
    private MenuCliente menuCliente = new MenuCliente();

    public void iniciar() {
        while (true) {
            System.out.println("\n=== Bienvenido a RapidExpress ===");
            System.out.print("Usuario: ");
            String username = scanner.nextLine();
            System.out.print("Contraseña: ");
            String password = scanner.nextLine();

            Usuario usuario = authService.autenticar(username, password);

            if (usuario == null) {
                System.out.println("Usuario o contraseña incorrectos.");
                continue;
            }

            switch (usuario.getRolId()) {
                case 1 -> menuAdmin.mostrarMenu(usuario);
                case 2 -> menuOperador.mostrarMenu(usuario);
                case 3 -> menuAuditor.mostrarMenu(usuario);
                case 4 -> menuCliente.mostrarMenu(usuario);
                default -> System.out.println("Rol no reconocido.");
            }
        }
    }
}
