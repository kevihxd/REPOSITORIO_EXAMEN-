package menus;

import java.util.Scanner;
import modelo.Usuario;
import procesos.ProcesoConductores;
import procesos.ProcesoVehiculos;
import procesos.ProcesoPaquetes;
import procesos.ProcesoRutas;

public class MenuOperador {

    private Scanner scanner = new Scanner(System.in);

    private ProcesoConductores procesoConductores = new ProcesoConductores();
    private ProcesoVehiculos procesoVehiculos = new ProcesoVehiculos();
    private ProcesoPaquetes procesoPaquetes = new ProcesoPaquetes();
    private ProcesoRutas procesoRutas = new ProcesoRutas();

    public void mostrarMenu(Usuario usuario) {
        int opcion;
        do {
            System.out.println("\n=== Menú Operador ===");
            System.out.println("1. Gestionar Conductores");
            System.out.println("2. Gestionar Vehículos");
            System.out.println("3. Gestionar Paquetes");
            System.out.println("4. Gestionar Rutas");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");
            opcion = leerOpcion(1, 5);

            switch (opcion) {
                case 1 -> menuConductores();
                case 2 -> menuVehiculos();
                case 3 -> menuPaquetes();
                case 4 -> menuRutas();
                case 5 -> System.out.println("Saliendo del menú Operador...");
            }
        } while (opcion != 5);
    }

    private int leerOpcion(int min, int max) {
        while (true) {
            try {
                int op = Integer.parseInt(scanner.nextLine());
                if (op >= min && op <= max) return op;
                System.out.println("Opción fuera de rango.");
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        }
    }

    // ===============================
    //  SUBMENÚS
    // ===============================

    private void menuConductores() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Conductores ---");
            System.out.println("1. Listar conductores");
            System.out.println("2. Buscar conductor por ID");
            System.out.println("3. Asignar conductor a ruta");
            System.out.println("4. Cambiar estado del conductor");
            System.out.println("5. Volver");
            System.out.print("Opción: ");
            opcion = leerOpcion(1, 5);
            switch (opcion) {
                case 1 -> procesoConductores.listarConductores();
                case 2 -> procesoConductores.buscarConductor();
                case 3 -> procesoConductores.asignarConductorRuta();
                case 4 -> procesoConductores.cambiarEstado();
                case 5 -> {}
            }
        } while (opcion != 5);
    }

    private void menuVehiculos() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Vehículos ---");
            System.out.println("1. Listar vehículos");
            System.out.println("2. Buscar vehículo por placa");
            System.out.println("3. Ver estado del vehículo");
            System.out.println("4. Volver");
            System.out.print("Opción: ");
            opcion = leerOpcion(1, 4);
            switch (opcion) {
                case 1 -> procesoVehiculos.listarVehiculos();
                case 2 -> procesoVehiculos.buscarVehiculo();
                case 3 -> procesoVehiculos.verEstadoVehiculo();
                case 4 -> {}
            }
        } while (opcion != 4);
    }

    private void menuPaquetes() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Paquetes ---");
            System.out.println("1. Registrar paquete");
            System.out.println("2. Listar paquetes");
            System.out.println("3. Buscar paquete por ID");
            System.out.println("4. Cambiar estado del paquete");
            System.out.println("5. Asignar paquete a ruta");
            System.out.println("6. Volver");
            System.out.print("Opción: ");
            opcion = leerOpcion(1, 6);
            switch (opcion) {
                case 1 -> procesoPaquetes.registrarPaquete();
                case 2 -> procesoPaquetes.listarPaquetes();
                case 3 -> procesoPaquetes.buscarPaquete();
                case 4 -> procesoPaquetes.cambiarEstadoPaquete();
                case 5 -> procesoPaquetes.asignarPaqueteRuta();
                case 6 -> {}
            }
        } while (opcion != 6);
    }

    private void menuRutas() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Rutas ---");
            System.out.println("1. Crear ruta");
            System.out.println("2. Listar rutas");
            System.out.println("3. Buscar ruta por ID");
            System.out.println("4. Asignar conductor a ruta");
            System.out.println("5. Asignar vehículo a ruta");
            System.out.println("6. Agregar paquetes a la ruta");
            System.out.println("7. Cambiar estado de la ruta");
            System.out.println("8. Cerrar ruta");
            System.out.println("9. Volver");
            System.out.print("Opción: ");
            opcion = leerOpcion(1, 9);
            switch (opcion) {
                case 1 -> procesoRutas.crearRuta();
                case 2 -> procesoRutas.listarRutasInteractivo();
                case 3 -> procesoRutas.buscarRutaInteractivo();
                case 4 -> procesoRutas.asignarConductor();
                case 5 -> procesoRutas.asignarVehiculo();
                case 6 -> procesoRutas.agregarPaquetes();
                case 7 -> procesoRutas.cambiarEstadoRuta();
                case 8 -> procesoRutas.cerrarRuta();
                case 9 -> {}
            }
        } while (opcion != 9);
    }
}