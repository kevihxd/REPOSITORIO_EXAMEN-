/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menus;

import java.util.Scanner;

import modelo.Usuario;
import procesos.ProcesoMenuAuditoria;

public class MenuAuditor {

    private final Scanner scanner = new Scanner(System.in);

    // Servicios (solo lectura)
    private final ProcesoMenuAuditoria proceso = new ProcesoMenuAuditoria();
    
    

    public void mostrarMenu(Usuario usuario) {
        int opcion;

        do {
            System.out.println("\n==============================");
            System.out.println("      MENÚ AUDITOR");
            System.out.println("==============================");
            System.out.println("Usuario: " + usuario.getNombre());
            System.out.println("1. Ver Paquetes");
            System.out.println("2. Ver Vehículos");
            System.out.println("3. Ver Conductores");
            System.out.println("4. Ver Rutas");
            System.out.println("5. Ver Detalle de Ruta");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1 -> proceso.verPaquetes();
                case 2 -> proceso.verVehiculos();
                case 3 -> proceso.verConductores();
                case 4 -> proceso.verRutas();
                case 5 -> proceso.verDetalleRuta();
                case 0 -> System.out.println("Saliendo del menú Auditor...");
                default -> System.out.println("Opción no válida, intente nuevamente.");
            }

        } while (opcion != 0);
    }

   
    
}


