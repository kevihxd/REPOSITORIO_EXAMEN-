/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menus;

import java.util.Scanner;
import modelo.Usuario;
import procesos.ProcesosMenuAdmin;
/**
 *
 * @author camper
 */
public class MenuAdmin {
    private Scanner scanner = new Scanner(System.in);
    
    //Procesos llamado
    private ProcesosMenuAdmin procesos = new ProcesosMenuAdmin();

    public void mostrarMenu(Usuario usuario) {
        int opcion;
        do {
            System.out.println("\n=== Menú Admin ===");
            System.out.println("1. Gestionar Usuarios");
            System.out.println("2. Gestionar Conductores");
            System.out.println("3. Gestionar Vehículos");
            System.out.println("4. Gestionar Paquetes");
            System.out.println("5. Gestionar Rutas");
            System.out.println("6. Salir");
            System.out.print("Elige una opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1 -> procesos.gestionarUsuarios();
                case 2 -> procesos.gestionarConductores();
                case 3 -> procesos.gestionarVehiculos();
                case 4 -> procesos.gestionarPaquetes();
                case 5 -> procesos.gestionarRutas();
                case 6 -> System.out.println("Saliendo del menú Admin...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 6);
    }
}
